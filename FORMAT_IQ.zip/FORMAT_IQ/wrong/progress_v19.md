# formatIQ progress v19 (chat 14; read with HANDOFF_v21, v23 to v26)

| Step | File | Status | Tests (sandbox, Node 22 + 18) |
|---|---|---|---|
| 0a-0d | config, types.ts, zipio.ts v2 | done | zipio 28 |
| 1a-1b | xml.ts, template_extract.ts | done | 12 + 27 |
| 2a-2b | paragraphs, structure_rules, structure_detect | done | 56 |
| 3a | xml_rewrite.ts, styles.ts | done | 32 + 22 |
| 3b-1 | restyle.ts | done | 21 |
| 3b-2b | package_merge.ts | done | 36 |
| 3b-3 | numbering_merge.ts | done | 29 |
| 3b-4 | validate.ts | done | 21 |
| 3b-5 | apply.ts + apply_sections.ts | done (other chat) | 21 + 11 |
| 5b | page_setup.ts | done (not yet wired into apply) | 39 |
| 5c | watermark.ts (NEW, chat 14) | done (not yet wired into apply; display in Word unchecked) | 35 |
| - | wire page_setup and watermark into apply.ts | NEXT | |
| - | types.ts growth (page setup, watermark options in FormatOptions) | next | |
| 3c | partial apply | next | |
| 5a | per-section header/footer choices, keepSourceHeaders | next | |
| 4a-4b | captions, cross-references | next | |
| - | toc.ts, tables, images, lists, notes, report, UI, template store, image reduction, batch | later (HANDOFF_v21 section 6) | |

Open caveats: real Word files not tried; real browser not tested; watermark VML unverified in Word; restyle test still needs a run against the real Drive paragraphs.ts and xml.ts; types.ts growth pending (v24, v26).
