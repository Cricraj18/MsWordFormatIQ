# formatIQ progress v17 (chat 12; read with HANDOFF_v21, v23, v24)

| Step | File | Status | Tests (sandbox, Node 22 + 18) |
|---|---|---|---|
| 0a-0d | config, types.ts, zipio.ts v2 | done | zipio 28 |
| 1a-1b | xml.ts, template_extract.ts | done | 12 + 27 |
| 2a-2b | paragraphs, structure_rules, structure_detect | done | 56 |
| 3a | xml_rewrite.ts, styles.ts | done | 32 + 22 |
| 3b-1 | restyle.ts | done | 21 |
| 3b-2b | package_merge.ts | done | 36 |
| 3b-3 | numbering_merge.ts (other chat) | done | 29 |
| 3b-4 | validate.ts (other chat) | done | 21 |
| 5b | page_setup.ts (NEW, chat 12) | done | 39 |
| 3b-5 | apply.ts | NEXT | |
| 3c | partial apply | next | |
| 5a | headers/footers inheritance | next | |
| 5c | watermark.ts | next | |
| 4a-4b | captions, cross-references | next | |
| - | toc.ts, tables, images, lists, notes, report, UI, template store, image reduction, batch | later (HANDOFF_v21 section 6) | |

Open caveats: real Word files not tried; real browser not tested; restyle test still needs a run against the real Drive paragraphs.ts and xml.ts; types.ts growth pending (HANDOFF_v24).
