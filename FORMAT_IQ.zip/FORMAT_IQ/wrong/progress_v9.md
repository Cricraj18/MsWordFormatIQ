# formatIQ progress v9 (chat 9)

| File | Written | Tests (sandbox) | ChatGPT review | Checked in real Word | Issues |
|---|---|---|---|---|---|
| 0a setup | yes | typecheck + build ok (Node 22) | not needed | n/a | package.json has sax, @types/sax, docx |
| 0b types.ts | yes | typecheck clean | no | n/a | none |
| 0c/0d zipio.ts + test | yes | 22 tests pass (chat 7, Node 22 + 18) | review v1 applied | n/a | not browser-tested |
| 1a-1 xml.ts + xml.test.ts | yes | 12 tests pass (Node 22 + 18) | no | n/a | strips prefixes, so it cannot write XML back (see HANDOFF_v13) |
| 1a-2 template_extract.ts + test | yes | 27 tests pass (Node 22 + 18) | no | n/a | only library-made .docx tried |
| 2a-1 paragraphs.ts (NEW) | yes | 18 tests pass (Node 22 + 18) | no | n/a | list set only by a style not seen; numbering.xml not read |
| 2a-2 structure_rules.ts (NEW) | yes | 24 tests pass (Node 22 + 18) | no | n/a | rules tuned only on made-up and library files |
| 2a-3 structure_detect.ts (NEW) | yes | 14 tests pass (Node 22 + 18) | no | n/a | two passes over document.xml |
| 2b tests | yes (3 test files) | 56 of 56 pass | no | n/a | |
| 3a-3c formatter | NEXT | | | | needs a raw XML rewriter first |

Totals new this chat: 56 tests. All run by Claude in the sandbox. The user was not asked to run anything.
