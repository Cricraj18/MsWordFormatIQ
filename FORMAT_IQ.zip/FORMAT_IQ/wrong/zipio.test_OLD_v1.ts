/**
 * Tests for zipio.ts (files 0c and 0d).
 * Run with: npm test
 * Zips are built in memory, so no sample files are needed.
 */
import { beforeAll, describe, expect, it } from "vitest";
import { BlobWriter, TextReader, Uint8ArrayReader, ZipWriter } from "@zip.js/zip.js";
import {
  createBlobZipOutput,
  createJobControl,
  hasAllowedExtension,
  isSafeZipPath,
  openDocx,
  readEntryText,
  setWorkersEnabled,
} from "./zipio";
import { FormatIQError } from "../types";

beforeAll(() => {
  setWorkersEnabled(false);
});

/** Build a zip Blob from simple files. Uses raw zip.js, so paths are not checked. */
async function makeZip(files: Record<string, string | Uint8Array>): Promise<Blob> {
  const writer = new ZipWriter(new BlobWriter());
  for (const [path, content] of Object.entries(files)) {
    if (typeof content === "string") {
      await writer.add(path, new TextReader(content));
    } else {
      await writer.add(path, new Uint8ArrayReader(content));
    }
  }
  return writer.close();
}

const GOOD_FILES: Record<string, string | Uint8Array> = {
  "[Content_Types].xml": "<Types/>",
  "word/document.xml": "<w:document>Hello</w:document>",
  "word/media/image1.png": new Uint8Array([1, 2, 3, 4, 5]),
};

async function expectCode(promise: Promise<unknown>, code: string): Promise<void> {
  try {
    await promise;
  } catch (err) {
    expect(err).toBeInstanceOf(FormatIQError);
    if (err instanceof FormatIQError) expect(err.code).toBe(code);
    return;
  }
  throw new Error(`Expected error ${code} but nothing was thrown`);
}

describe("small checks", () => {
  it("accepts only .docx and .docm", () => {
    expect(hasAllowedExtension("a.docx")).toBe(true);
    expect(hasAllowedExtension("A.DOCM")).toBe(true);
    expect(hasAllowedExtension("a.pdf")).toBe(false);
    expect(hasAllowedExtension("a.docx.exe")).toBe(false);
  });

  it("accepts normal zip paths", () => {
    expect(isSafeZipPath("word/document.xml")).toBe(true);
    expect(isSafeZipPath("word/media/")).toBe(true);
  });

  it("rejects unsafe zip paths", () => {
    expect(isSafeZipPath("")).toBe(false);
    expect(isSafeZipPath("../evil.xml")).toBe(false);
    expect(isSafeZipPath("word/../../evil.xml")).toBe(false);
    expect(isSafeZipPath("/etc/passwd")).toBe(false);
    expect(isSafeZipPath("C:/x.xml")).toBe(false);
    expect(isSafeZipPath("word\\document.xml")).toBe(false);
  });
});

describe("openDocx", () => {
  it("rejects a wrong extension", async () => {
    const blob = await makeZip(GOOD_FILES);
    await expectCode(openDocx(blob, "file.pdf"), "NOT_DOCX");
  });

  it("opens a good file and lists entries", async () => {
    const opened = await openDocx(await makeZip(GOOD_FILES), "ok.docx");
    expect(opened.entries.size).toBe(3);
    expect(opened.entries.has("word/document.xml")).toBe(true);
    await opened.close();
  });

  it("rejects a zip without word/document.xml", async () => {
    const blob = await makeZip({ "[Content_Types].xml": "<Types/>" });
    await expectCode(openDocx(blob, "x.docx"), "NOT_DOCX");
  });

  it("rejects an unsafe path inside the zip", async () => {
    const blob = await makeZip({ ...GOOD_FILES, "../evil.xml": "x" });
    await expectCode(openDocx(blob, "x.docx"), "UNSAFE_ZIP_PATH");
  });

  it("rejects a document.xml over the size limit", async () => {
    const blob = await makeZip(GOOD_FILES);
    const limits = { maxEntries: 100, maxTotalBytes: 1e9, maxXmlBytes: 5, timeoutMs: 5000 };
    await expectCode(openDocx(blob, "x.docx", limits), "XML_TOO_LARGE");
  });
});

describe("readEntryText", () => {
  it("reads text", async () => {
    const opened = await openDocx(await makeZip(GOOD_FILES), "ok.docx");
    const entry = opened.entries.get("word/document.xml");
    expect(entry).toBeDefined();
    if (entry === undefined) return;
    expect(await readEntryText(entry, 1000)).toBe("<w:document>Hello</w:document>");
    await opened.close();
  });

  it("stops when real output is bigger than the cap", async () => {
    const opened = await openDocx(await makeZip(GOOD_FILES), "ok.docx");
    const entry = opened.entries.get("word/document.xml");
    if (entry === undefined) throw new Error("missing entry");
    await expectCode(readEntryText(entry, 5), "FILE_TOO_LARGE");
    await opened.close();
  });

  it("reports CANCELLED when the job is already aborted", async () => {
    const opened = await openDocx(await makeZip(GOOD_FILES), "ok.docx");
    const entry = opened.entries.get("word/document.xml");
    if (entry === undefined) throw new Error("missing entry");
    const user = new AbortController();
    user.abort();
    const control = createJobControl(5000, user.signal);
    await expectCode(readEntryText(entry, 1000, control), "CANCELLED");
    control.dispose();
    await opened.close();
  });
});

describe("writing", () => {
  it("copies parts untouched and adds a changed part", async () => {
    const source = await openDocx(await makeZip(GOOD_FILES), "in.docx");
    const { output, getBlob } = createBlobZipOutput();
    await output.addText("word/document.xml", "<w:document>Changed</w:document>");
    const types = source.entries.get("[Content_Types].xml");
    const image = source.entries.get("word/media/image1.png");
    if (types === undefined || image === undefined) throw new Error("missing entry");
    await output.copyEntry(types);
    await output.copyEntry(image);
    await output.finish();
    await source.close();

    const result = await openDocx(await getBlob(), "out.docx");
    const doc = result.entries.get("word/document.xml");
    if (doc === undefined) throw new Error("missing document.xml");
    expect(await readEntryText(doc, 1000)).toBe("<w:document>Changed</w:document>");
    const copied = result.entries.get("word/media/image1.png");
    if (copied === undefined) throw new Error("missing image");
    expect(await readEntryText(copied, 1000)).toBe("\u0001\u0002\u0003\u0004\u0005");
    await result.close();
  });

  it("refuses to write an unsafe path", async () => {
    const { output } = createBlobZipOutput();
    await expectCode(output.addText("../evil.xml", "x"), "UNSAFE_ZIP_PATH");
  });
});
