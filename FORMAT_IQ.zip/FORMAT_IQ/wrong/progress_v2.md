# formatIQ progress v2

| File | Written | Tests pass | ChatGPT review | Checked in Word | Issues |
|---|---|---|---|---|---|
| 0a setup | yes | not run yet | not needed | n/a | package versions UNSURE |
| 0b types.ts | | | | | |
| 0c zipio read | | | | | |
| 0d zipio write | | | | | |

User to-do for 0a: install Node.js (LTS), open a terminal in the project folder, run: npm install, npm run typecheck, npm test, npm run dev. Report results.
