import { beforeAll, describe, expect, it } from "vitest";
import { BlobWriter, TextReader, ZipWriter, configure } from "@zip.js/zip.js";
import { validateDocx } from "./validate";
import type { ProblemCode, ValidationReport } from "./validate";

const W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
const R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
const REL = "http://schemas.openxmlformats.org/package/2006/relationships";
const CT = "http://schemas.openxmlformats.org/package/2006/content-types";
const RT = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/";

const CONTENT_TYPES =
  '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="' + CT + '">' +
  '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
  '<Default Extension="xml" ContentType="application/xml"/>' +
  '<Default Extension="png" ContentType="image/png"/>' +
  '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>' +
  "</Types>";
const ROOT_RELS =
  '<?xml version="1.0"?><Relationships xmlns="' + REL + '">' +
  '<Relationship Id="rId1" Type="' + RT + 'officeDocument" Target="word/document.xml"/></Relationships>';
const DOC_RELS =
  '<?xml version="1.0"?><Relationships xmlns="' + REL + '">' +
  '<Relationship Id="rId1" Type="' + RT + 'styles" Target="styles.xml"/>' +
  '<Relationship Id="rId2" Type="' + RT + 'numbering" Target="numbering.xml"/>' +
  '<Relationship Id="rId3" Type="' + RT + 'hyperlink" Target="https://example.com/" TargetMode="External"/>' +
  "</Relationships>";
const STYLES =
  '<?xml version="1.0"?><w:styles xmlns:w="' + W + '">' +
  '<w:style w:type="paragraph" w:styleId="Normal"><w:name w:val="Normal"/></w:style>' +
  '<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/></w:style></w:styles>';
const NUMBERING =
  '<?xml version="1.0"?><w:numbering xmlns:w="' + W + '">' +
  '<w:abstractNum w:abstractNumId="0"/><w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num></w:numbering>';
const SECT = '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr>';

/** Build a document.xml with a body. */
function doc(body: string, extraNs = ""): string {
  return '<?xml version="1.0"?><w:document xmlns:w="' + W + '" xmlns:r="' + R + '"' + extraNs + "><w:body>" + body + SECT + "</w:body></w:document>";
}

/** A clean file set; tests override single entries. */
function cleanFiles(): Record<string, string> {
  return {
    "[Content_Types].xml": CONTENT_TYPES,
    "_rels/.rels": ROOT_RELS,
    "word/_rels/document.xml.rels": DOC_RELS,
    "word/styles.xml": STYLES,
    "word/numbering.xml": NUMBERING,
    "word/document.xml": doc('<w:p><w:pPr><w:pStyle w:val="Heading1"/><w:numPr><w:ilvl w:val="0"/><w:numId w:val="1"/></w:numPr></w:pPr><w:r><w:t>Hi</w:t></w:r></w:p>'),
  };
}

/** Zip a map of text files into a Blob. */
async function makeZip(files: Record<string, string>): Promise<Blob> {
  const bw = new BlobWriter("application/zip");
  const zw = new ZipWriter(bw);
  for (const [name, text] of Object.entries(files)) {
    await zw.add(name, new TextReader(text));
  }
  return zw.close();
}

/** Validate a file set and return the report. */
async function run(files: Record<string, string>): Promise<ValidationReport> {
  return validateDocx(await makeZip(files));
}

/** Codes found in a report. */
function codes(report: ValidationReport): ProblemCode[] {
  return report.problems.map((p) => p.code);
}

beforeAll(() => {
  configure({ useWebWorkers: false });
});

describe("validateDocx: clean file", () => {
  it("returns no problems for a clean file", async () => {
    const r = await run(cleanFiles());
    expect(r.problems).toEqual([]);
    expect(r.ok).toBe(true);
    expect(r.errorCount).toBe(0);
    expect(r.warningCount).toBe(0);
  });

  it("does not flag External relationships", async () => {
    const r = await run(cleanFiles());
    expect(codes(r)).not.toContain("REL_TARGET_MISSING");
  });

  it("accepts numId 0 (no list)", async () => {
    const f = cleanFiles();
    f["word/document.xml"] = doc('<w:p><w:pPr><w:numPr><w:numId w:val="0"/></w:numPr></w:pPr></w:p>');
    expect((await run(f)).problems).toEqual([]);
  });

  it("works with other prefixes for the same namespaces", async () => {
    const f = cleanFiles();
    f["word/document.xml"] =
      '<?xml version="1.0"?><x:document xmlns:x="' + W + '" xmlns:q="' + R + '"><x:body>' +
      '<x:p><x:hyperlink q:id="rId3"/></x:p>' + SECT.replace(/w:/g, "x:").replace("<x:sectPr>", "<x:sectPr>") +
      "</x:body></x:document>";
    // sectPr above still uses prefix x via replace; rId3 is defined in rels
    const r = await run(f);
    expect(r.problems).toEqual([]);
  });
});

describe("validateDocx: package problems", () => {
  it("reports a file that is not a zip", async () => {
    const r = await validateDocx(new Blob(["this is not a zip file"]));
    expect(codes(r)).toEqual(["ZIP_UNREADABLE"]);
    expect(r.ok).toBe(false);
  });

  it("reports missing [Content_Types].xml", async () => {
    const f = cleanFiles();
    delete f["[Content_Types].xml"];
    expect(codes(await run(f))).toContain("CONTENT_TYPES_MISSING");
  });

  it("reports a part without a content type", async () => {
    const f = cleanFiles();
    f["word/media/odd.bin"] = "x";
    const r = await run(f);
    expect(r.problems.find((p) => p.code === "CONTENT_TYPE_MISSING")?.part).toBe("word/media/odd.bin");
  });

  it("reports a missing document part", async () => {
    const f = cleanFiles();
    delete f["word/document.xml"];
    const c = codes(await run(f));
    expect(c).toContain("DOCUMENT_MISSING");
    expect(c).toContain("REL_TARGET_MISSING");
  });

  it("reports a relationship target that is missing", async () => {
    const f = cleanFiles();
    f["word/_rels/document.xml.rels"] = DOC_RELS.replace("</Relationships>", '<Relationship Id="rId9" Type="' + RT + 'image" Target="media/gone.png"/></Relationships>');
    const r = await run(f);
    const p = r.problems.find((x) => x.code === "REL_TARGET_MISSING");
    expect(p?.message).toContain("word/media/gone.png");
  });

  it("resolves absolute targets from the package root", async () => {
    const f = cleanFiles();
    f["word/_rels/document.xml.rels"] = DOC_RELS.replace('Target="styles.xml"', 'Target="/word/styles.xml"');
    expect((await run(f)).problems).toEqual([]);
  });

  it("flags a target that climbs out of the package", async () => {
    const f = cleanFiles();
    f["word/_rels/document.xml.rels"] = DOC_RELS.replace('Target="styles.xml"', 'Target="../../../etc/passwd"');
    expect(codes(await run(f))).toContain("REL_TARGET_UNSAFE");
  });
});

describe("validateDocx: references, styles, numbering, bookmarks, sections", () => {
  it("reports an r:id that has no relationship", async () => {
    const f = cleanFiles();
    f["word/document.xml"] = doc('<w:p><w:hyperlink r:id="rId77"/></w:p>');
    const r = await run(f);
    expect(r.problems.find((p) => p.code === "REL_ID_UNRESOLVED")?.message).toContain("rId77");
  });

  it("checks r:id in a header against the header's own rels", async () => {
    const f = cleanFiles();
    f["word/header1.xml"] = '<?xml version="1.0"?><w:hdr xmlns:w="' + W + '" xmlns:r="' + R + '"><w:p><w:hyperlink r:id="rId1"/></w:p></w:hdr>';
    f["word/_rels/header1.xml.rels"] = '<?xml version="1.0"?><Relationships xmlns="' + REL + '"></Relationships>';
    const r = await run(f);
    const p = r.problems.find((x) => x.code === "REL_ID_UNRESOLVED");
    expect(p?.part).toBe("word/header1.xml");
  });

  it("reports a header reference that dangles", async () => {
    const f = cleanFiles();
    f["word/document.xml"] = doc("<w:p/>").replace("<w:sectPr>", '<w:sectPr><w:headerReference w:type="default" r:id="rId50"/>');
    expect(codes(await run(f))).toContain("REL_ID_UNRESOLVED");
  });

  it("warns about a paragraph style that is not defined", async () => {
    const f = cleanFiles();
    f["word/document.xml"] = doc('<w:p><w:pPr><w:pStyle w:val="Ghost"/></w:pPr></w:p>');
    const r = await run(f);
    expect(r.problems).toHaveLength(1);
    expect(r.problems[0]?.severity).toBe("warning");
    expect(r.problems[0]?.code).toBe("STYLE_MISSING");
    expect(r.ok).toBe(true);
  });

  it("warns once when styles.xml is missing", async () => {
    const f = cleanFiles();
    delete f["word/styles.xml"];
    f["word/_rels/document.xml.rels"] = DOC_RELS.replace(/<Relationship Id="rId1"[^>]*\/>/, "");
    f["word/document.xml"] = doc('<w:p><w:pPr><w:pStyle w:val="A"/></w:pPr></w:p><w:p><w:pPr><w:pStyle w:val="B"/></w:pPr></w:p>');
    const r = await run(f);
    expect(codes(r).filter((c) => c === "STYLES_PART_MISSING")).toHaveLength(1);
  });

  it("reports a numId that numbering.xml does not define", async () => {
    const f = cleanFiles();
    f["word/document.xml"] = doc('<w:p><w:pPr><w:numPr><w:numId w:val="9"/></w:numPr></w:pPr></w:p>');
    expect(codes(await run(f))).toContain("NUMID_MISSING");
  });

  it("reports duplicate bookmark ids", async () => {
    const f = cleanFiles();
    f["word/document.xml"] = doc('<w:p><w:bookmarkStart w:id="3" w:name="a"/><w:bookmarkEnd w:id="3"/><w:bookmarkStart w:id="3" w:name="b"/></w:p>');
    expect(codes(await run(f))).toContain("BOOKMARK_DUPLICATE_ID");
  });

  it("accepts different bookmark ids", async () => {
    const f = cleanFiles();
    f["word/document.xml"] = doc('<w:p><w:bookmarkStart w:id="1" w:name="a"/><w:bookmarkStart w:id="2" w:name="b"/></w:p>');
    expect((await run(f)).problems).toEqual([]);
  });

  it("reports a section without page size", async () => {
    const f = cleanFiles();
    f["word/document.xml"] = doc('<w:p><w:pPr><w:sectPr><w:pgMar w:top="1"/></w:sectPr></w:pPr></w:p>');
    const r = await run(f);
    expect(r.problems.find((p) => p.code === "SECTPR_MALFORMED")?.message).toContain("pgSz");
  });

  it("reports a non-numeric page size and repeated header types", async () => {
    const f = cleanFiles();
    const bad = '<w:sectPr><w:headerReference w:type="default" r:id="rId1"/><w:headerReference w:type="default" r:id="rId1"/><w:pgSz w:w="abc" w:h="16838"/></w:sectPr>';
    f["word/document.xml"] = doc('<w:p><w:pPr>' + bad + "</w:pPr></w:p>");
    const msgs = (await run(f)).problems.filter((p) => p.code === "SECTPR_MALFORMED").map((p) => p.message);
    expect(msgs.some((m) => m.includes("repeated"))).toBe(true);
    expect(msgs.some((m) => m.includes("positive number"))).toBe(true);
  });
});

describe("validateDocx: bad XML", () => {
  it("reports damaged XML in document.xml as an error, without throwing", async () => {
    const f = cleanFiles();
    f["word/document.xml"] = '<w:document xmlns:w="' + W + '"><w:body><w:p></w:body>';
    const r = await run(f);
    expect(r.problems.find((p) => p.part === "word/document.xml")?.code).toBe("XML_INVALID");
    expect(r.ok).toBe(false);
  });

  it("reports a DOCTYPE", async () => {
    const f = cleanFiles();
    f["word/document.xml"] = '<?xml version="1.0"?><!DOCTYPE d [<!ENTITY a "b">]><w:document xmlns:w="' + W + '"/>';
    expect(codes(await run(f))).toContain("XML_DOCTYPE");
  });

  it("reports an XML part over the size limit", async () => {
    const blob = await makeZip(cleanFiles());
    const r = await validateDocx(blob, { maxXmlBytes: 10 });
    expect(codes(r)).toContain("XML_TOO_LARGE");
  });

  it("reports damaged rels", async () => {
    const f = cleanFiles();
    f["word/_rels/document.xml.rels"] = "<Relationships><Relationship";
    const r = await run(f);
    expect(r.problems.find((p) => p.part === "word/_rels/document.xml.rels")?.code).toBe("XML_INVALID");
  });
});
