# formatIQ TEST STATUS v11 (chat 12; replaces TEST_STATUS_v10; read with HANDOFF_v21, v22, v23)

Method: sandbox (Linux, 4 GB RAM, 1 CPU). Node 22.22.2 and Node 18.20.8 (npm i node@18 in /tmp/n18). Vitest 2.1.9, TypeScript 5.9.3, Vite 5.4.21, sax 1.6.1, @zip.js/zip.js 2.23.0. Sandbox package.json/tsconfig/vite.config rebuilt from HANDOFF_v21 facts (Drive package.json build script: "tsc --noEmit && vite build"). Only validate.ts and its test were in the sandbox this chat (validate.ts imports only sax and zip.js).

## TESTED (really run, chat 12)
- src/core/validate.ts (17162 bytes) + validate.test.ts (11830 bytes): 25 of 25 tests pass on Node 22.22.2 AND Node 18.20.8; typecheck clean (strict, noUncheckedIndexedAccess, noUnused*); npm run build ok with a temporary entry (bundle 159 kB, 69 kB gzip; entry and index.html removed afterwards); no "any", no non-null "!", no non-ASCII characters (searched). Drive copies have the same byte sizes as the sandbox copies.
- Coverage: clean file (no problems), External rels not flagged, numId 0 accepted, other namespace prefixes; not a zip, missing [Content_Types].xml, part without content type, missing document part, missing rels target, absolute targets, target climbing out (REL_TARGET_UNSAFE); unresolved r:id in document, in a header (own rels), dangling header reference in sectPr; undefined pStyle (warning, ok stays true), styles.xml missing (one warning), undefined numId, duplicate and distinct bookmark ids, sectPr without pgSz, non-numeric pgSz and repeated header type; damaged document XML, DOCTYPE, XML over size limit, damaged rels.
- Earlier chats (NOT redone, still valid): numbering_merge 29 tests (chat 11, Node 22 and 18); zipio v2 28, package_merge 36, restyle 21, xml_rewrite 32, styles 22 (139 tests in chat 10); xml 12, template_extract 27, paragraphs/structure 56 (chats 7 to 9). The full Drive suite was NOT rerun together in chats 11 or 12.

## CAVEATS (open)
1. restyle.test.ts still needs a run against the real Drive paragraphs.ts and xml.ts (do it when apply.ts is built).
2. numbering_merge was tested on hand-made numbering XML, not on the numbering.xml of a real Word file; w:styleLink / w:numStyleLink only produce a warning.
3. When the template has no numbering part but the source has one, apply.ts must add a word/numbering.xml part, a relationship and a content-type Override (mergeNumbering gives the merged text with shift 0).
4. validate.ts was tested on hand-made zips only; it checks pStyle but not rStyle/tblStyle; it does not cross-check footnote or comment ids.
5. validate.ts does not reuse package_merge/zipio (standalone by design in chat 12); a later cleanup could switch it to those files.

## NOT TESTED
1. Real browser (zip.js Web Workers, sax in a browser bundle, file picker, showSaveFilePicker, dev server page): headless browser download blocked.
2. A true 1 GB docx (600 MB tested in chat 6); addBlob parts over 20 MB; zip.js passThrough.
3. Files saved by real Word, LibreOffice, Google Docs.
4. Cancel mid-write on a real disk stream; UTF-16 XML parts; 200 MB document.xml.
5. Lists set only by a style, localized style names, font-based code detection.
6. apply.ts (not built yet); page setup, header/footer inheritance, watermark, sections, captions, cross-references, TOC, tables, images, notes, report, UI, template store, image reduction, batch (not built).
