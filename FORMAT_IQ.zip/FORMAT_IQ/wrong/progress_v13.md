# formatIQ progress v13 (chat 10)

| File | Written | Tests (sandbox) | ChatGPT review | Checked in real Word | Issues |
|---|---|---|---|---|---|
| 0a setup | yes | typecheck + build ok (Node 22) | not needed | n/a | package.json has sax, @types/sax, docx |
| 0b types.ts | yes | typecheck clean | no | n/a | must grow for page setup, watermark (HANDOFF_v16) |
| 0c/0d zipio.ts v2 + test (UPDATED) | yes | 28 tests pass (Node 22 + 18); old 22 plus 6 for addBlob | review v1 applied | n/a | not browser-tested |
| 1a-1 xml.ts + xml.test.ts | yes | 12 tests pass (Node 22 + 18) | no | n/a | strips prefixes, cannot write XML back |
| 1a-2 template_extract.ts + test | yes | 27 tests pass (Node 22 + 18) | no | n/a | only library-made .docx tried |
| 2a-1 paragraphs.ts | yes | 18 tests pass (Node 22 + 18) | no | n/a | list set only by a style not seen; numbering.xml not read |
| 2a-2 structure_rules.ts | yes | 24 tests pass (Node 22 + 18) | no | n/a | rules tuned only on made-up and library files |
| 2a-3 structure_detect.ts | yes | 14 tests pass (Node 22 + 18) | no | n/a | two passes over document.xml |
| 3a-1 xml_rewrite.ts + test | yes | 32 tests pass (Node 22 + 18) | no | n/a | works on strings |
| 3a-2 styles.ts + test | yes | 22 tests pass (Node 22 + 18) | no | n/a | localized names only via id pattern |
| 3b-1 restyle.ts + test | yes | 21 tests pass (Node 22 + 18) | no | n/a | clears only the paragraph's own direct formatting; numbering not merged yet |
| 3b-2 package_merge.ts, numbering_merge.ts, apply.ts, validate.ts | NEXT | | | | design in HANDOFF_v19 |
| 3c partial apply | NEXT | | | | |
| 5a-5c headers/footers, page setup, sections, watermark | NEXT | | | | HANDOFF_v16 |
| Tier 2 and 3 features | NEXT | | | | HANDOFF_v17 |

Totals new tests this chat (chat 10): 81 (32 xml_rewrite + 22 styles + 21 restyle + 6 zipio addBlob). All run by Claude in the sandbox. The user was not asked to run anything.
