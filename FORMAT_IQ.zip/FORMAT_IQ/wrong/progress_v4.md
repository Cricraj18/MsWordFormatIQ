# formatIQ progress v4

| File | Written | Tests pass | ChatGPT review | Checked in Word | Issues |
|---|---|---|---|---|---|
| 0a setup | yes | not run yet | not needed | n/a | package versions UNSURE; @zip.js/zip.js not in package.json yet |
| 0b types.ts | yes | not run yet | | n/a | no own test file; setPrototypeOf vs target UNSURE (harmless) |
| 0c zipio read | yes | not run yet | | n/a | zip.js API points UNSURE (see HANDOFF_v5) |
| 0d zipio write | yes | not run yet | | n/a | not a raw copy; media stored at level 0; file about 330 lines |

User to-do at the office (in the FORMAT_IQ project folder, with src/types.ts and src/core/zipio.ts + zipio.test.ts in place):
1. Install Node.js (LTS).
2. npm install
3. npm install @zip.js/zip.js
4. npm run typecheck   (expect: no errors)
5. npm test            (expect: all tests pass: version test + zipio tests)
6. npm run dev         (expect: page opens)
Report exactly what happened, including full error text. TEST GATE: 1a is blocked until then.
