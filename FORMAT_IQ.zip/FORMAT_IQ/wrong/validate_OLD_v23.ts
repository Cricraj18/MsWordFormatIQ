/**
 * formatIQ validate.ts (step 3b-4).
 *
 * Re-opens a finished .docx and returns a LIST of problems. It never throws
 * for a bad document; a bad document is a normal result here.
 *
 * Checks (from HANDOFF_v21 section 7):
 *  1. every part has a content type ([Content_Types].xml)
 *  2. every relationship target exists in the zip (External targets skipped)
 *  3. every r:id style attribute used in document, header, footer, footnote,
 *     endnote and comment parts resolves in that part's .rels file
 *  4. every pStyle id exists in word/styles.xml (warning)
 *  5. every w:sectPr is well formed (one pgSz with numeric w/h, no repeats)
 *  6. every numId exists in word/numbering.xml (numId 0 means "no list")
 *  7. bookmark ids are unique per part
 *
 * Design note: this file imports only "sax" and "@zip.js/zip.js" (no other
 * formatIQ file), so it can be tested alone. Namespaces are matched by URI,
 * so any prefix works.
 */
import sax from "sax";
import { BlobReader, ZipReader } from "@zip.js/zip.js";
import type { Entry } from "@zip.js/zip.js";

/** Word main namespace. */
const W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
/** Office relationships namespace (the "r:" prefix). */
const R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
/** Package relationships namespace (rels files). */
const PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships";
/** Content types namespace. */
const CT_NS = "http://schemas.openxmlformats.org/package/2006/content-types";

/** Default cap for one XML part when validating (256 MiB, as zipio). */
export const DEFAULT_VALIDATE_MAX_XML_BYTES = 256 * 1024 * 1024;

/** How serious a problem is. Errors mean Word may refuse or repair the file. */
export type ProblemSeverity = "error" | "warning";

/** Machine-readable problem codes. */
export type ProblemCode =
  | "ZIP_UNREADABLE"
  | "CONTENT_TYPES_MISSING"
  | "CONTENT_TYPE_MISSING"
  | "XML_INVALID"
  | "XML_DOCTYPE"
  | "XML_TOO_LARGE"
  | "REL_TARGET_MISSING"
  | "REL_TARGET_UNSAFE"
  | "REL_ID_UNRESOLVED"
  | "STYLE_MISSING"
  | "STYLES_PART_MISSING"
  | "SECTPR_MALFORMED"
  | "NUMID_MISSING"
  | "BOOKMARK_DUPLICATE_ID"
  | "DOCUMENT_MISSING";

/** One problem found in the file. */
export interface ValidationProblem {
  severity: ProblemSeverity;
  code: ProblemCode;
  /** Part name inside the zip, for example "word/document.xml". */
  part: string;
  /** Short plain-English message. */
  message: string;
}

/** Result of validateDocx. */
export interface ValidationReport {
  problems: ValidationProblem[];
  errorCount: number;
  warningCount: number;
  /** True when there are no errors (warnings are allowed). */
  ok: boolean;
}

/** Options for validateDocx. */
export interface ValidateOptions {
  /** Largest XML part to read, in bytes. Default 256 MiB. */
  maxXmlBytes?: number;
}

/** One XML attribute, namespace resolved. */
interface Attr {
  local: string;
  uri: string;
  value: string;
}

/** Callbacks used by parseXmlPart. */
interface XmlCallbacks {
  open(local: string, uri: string, attrs: Attr[]): void;
  close(local: string, uri: string): void;
}

/** One relationship read from a .rels file. */
interface Rel {
  id: string;
  target: string;
  external: boolean;
}

/** Join and normalise a relationship target. Returns null if it climbs out. */
function resolveTarget(baseDir: string, target: string): string | null {
  let raw = target;
  try {
    raw = decodeURIComponent(target);
  } catch {
    raw = target;
  }
  const joined = raw.startsWith("/") ? raw.slice(1) : baseDir + raw;
  const out: string[] = [];
  for (const seg of joined.split("/")) {
    if (seg === "" || seg === ".") continue;
    if (seg === "..") {
      if (out.length === 0) return null;
      out.pop();
    } else {
      out.push(seg);
    }
  }
  return out.join("/");
}

/** Directory of a part name, with trailing slash ("word/document.xml" -> "word/"). */
function dirOf(partName: string): string {
  const i = partName.lastIndexOf("/");
  return i < 0 ? "" : partName.slice(0, i + 1);
}

/** Owner part of a rels file ("word/_rels/document.xml.rels" -> "word/document.xml"). */
function ownerOfRels(relsName: string): string {
  const i = relsName.lastIndexOf("_rels/");
  const dir = i < 0 ? "" : relsName.slice(0, i);
  const file = relsName.slice(i < 0 ? 0 : i + 6, relsName.length - 5);
  return dir + file;
}

/** Turn a sax tag into a local name, uri and plain attribute list. */
function readTag(tag: sax.Tag | sax.QualifiedTag): { local: string; uri: string; attrs: Attr[] } {
  const attrs: Attr[] = [];
  let local = tag.name;
  let uri = "";
  if ("local" in tag) {
    local = tag.local;
    uri = tag.uri;
    for (const key of Object.keys(tag.attributes)) {
      const a = tag.attributes[key];
      if (a !== undefined) attrs.push({ local: a.local, uri: a.uri, value: a.value });
    }
  } else {
    for (const key of Object.keys(tag.attributes)) {
      const v = tag.attributes[key];
      if (typeof v === "string") attrs.push({ local: key, uri: "", value: v });
    }
  }
  return { local, uri, attrs };
}

/**
 * Stream one zip entry through the sax parser. Returns an error message when
 * the XML is damaged or uses a DOCTYPE, otherwise null.
 */
async function parseXmlPart(
  entry: Entry,
  maxBytes: number,
  callbacks: XmlCallbacks,
): Promise<{ kind: "ok" } | { kind: "bad"; code: ProblemCode; message: string }> {
  if (entry.directory) return { kind: "ok" };
  if (entry.uncompressedSize > maxBytes) {
    return { kind: "bad", code: "XML_TOO_LARGE", message: "This part is larger than the allowed size." };
  }
  const parser = sax.parser(true, { xmlns: true });
  const stack: Array<{ local: string; uri: string }> = [];
  let failure: { code: ProblemCode; message: string } | null = null;
  parser.onerror = (err: Error): void => {
    if (failure === null) failure = { code: "XML_INVALID", message: err.message.split("\n")[0] ?? "Damaged XML" };
  };
  parser.ondoctype = (): void => {
    if (failure === null) failure = { code: "XML_DOCTYPE", message: "XML uses a DOCTYPE, which is not allowed." };
  };
  parser.onopentag = (tag: sax.Tag | sax.QualifiedTag): void => {
    const t = readTag(tag);
    stack.push({ local: t.local, uri: t.uri });
    callbacks.open(t.local, t.uri, t.attrs);
  };
  parser.onclosetag = (): void => {
    const top = stack.pop();
    if (top !== undefined) callbacks.close(top.local, top.uri);
  };
  const decoder = new TextDecoder("utf-8");
  const sink = new WritableStream<Uint8Array>({
    write(chunk): void {
      if (failure === null) parser.write(decoder.decode(chunk, { stream: true }));
    },
    close(): void {
      if (failure === null) {
        parser.write(decoder.decode());
        parser.close();
      }
    },
  });
  try {
    await entry.getData(sink);
  } catch (err) {
    if (failure === null) {
      failure = { code: "XML_INVALID", message: err instanceof Error ? err.message : "Could not read part" };
    }
  }
  return failure === null ? { kind: "ok" } : { kind: "bad", ...(failure as { code: ProblemCode; message: string }) };
}

/** Facts collected from one content part. */
interface PartFacts {
  rIds: Set<string>;
  pStyles: Set<string>;
  numIds: Set<string>;
  bookmarkDuplicates: Set<string>;
  sectProblems: string[];
}

/** Collect the facts validate needs from a document-like part. */
function createFactsCollector(): { facts: PartFacts; callbacks: XmlCallbacks } {
  const facts: PartFacts = {
    rIds: new Set(),
    pStyles: new Set(),
    numIds: new Set(),
    bookmarkDuplicates: new Set(),
    sectProblems: [],
  };
  const bookmarkIds = new Set<string>();
  let sect: { pgSz: number; pgMar: number; badSize: boolean; refs: Set<string> } | null = null;
  const callbacks: XmlCallbacks = {
    open(local, uri, attrs): void {
      for (const a of attrs) {
        if (a.uri === R_NS && a.value !== "") facts.rIds.add(a.value);
      }
      if (uri !== W_NS) return;
      const val = attrs.find((a) => a.uri === W_NS && a.local === "val")?.value;
      if (local === "pStyle" && val !== undefined) facts.pStyles.add(val);
      if (local === "numId" && val !== undefined) facts.numIds.add(val);
      if (local === "bookmarkStart") {
        const id = attrs.find((a) => a.uri === W_NS && a.local === "id")?.value;
        if (id !== undefined) {
          if (bookmarkIds.has(id)) facts.bookmarkDuplicates.add(id);
          bookmarkIds.add(id);
        }
      }
      if (local === "sectPr") sect = { pgSz: 0, pgMar: 0, badSize: false, refs: new Set() };
      if (sect !== null) {
        if (local === "pgSz") {
          sect.pgSz += 1;
          const w = Number(attrs.find((a) => a.local === "w")?.value);
          const h = Number(attrs.find((a) => a.local === "h")?.value);
          if (!Number.isFinite(w) || !Number.isFinite(h) || w <= 0 || h <= 0) sect.badSize = true;
        }
        if (local === "pgMar") sect.pgMar += 1;
        if (local === "headerReference" || local === "footerReference") {
          const type = attrs.find((a) => a.uri === W_NS && a.local === "type")?.value ?? "default";
          const key = local + ":" + type;
          if (sect.refs.has(key)) facts.sectProblems.push("repeated " + local + " type " + type);
          sect.refs.add(key);
        }
      }
    },
    close(local, uri): void {
      if (uri !== W_NS || local !== "sectPr" || sect === null) return;
      if (sect.pgSz === 0) facts.sectProblems.push("no page size (pgSz)");
      if (sect.pgSz > 1) facts.sectProblems.push("more than one pgSz");
      if (sect.badSize) facts.sectProblems.push("pgSz width or height is not a positive number");
      if (sect.pgMar > 1) facts.sectProblems.push("more than one pgMar");
      sect = null;
    },
  };
  return { facts, callbacks };
}

/** Parts whose references and styles are checked. */
const CONTENT_PART = /^word\/(document|header\d*|footer\d*|footnotes|endnotes|comments)\.xml$/;

/**
 * Validate a .docx. Never throws for a bad file: a bad file is reported as
 * problems. Only unexpected programming errors can reject the promise.
 */
export async function validateDocx(source: Blob, options: ValidateOptions = {}): Promise<ValidationReport> {
  const problems: ValidationProblem[] = [];
  const maxXml = options.maxXmlBytes ?? DEFAULT_VALIDATE_MAX_XML_BYTES;
  const add = (severity: ProblemSeverity, code: ProblemCode, part: string, message: string): void => {
    problems.push({ severity, code, part, message });
  };
  const finish = (): ValidationReport => {
    const errorCount = problems.filter((p) => p.severity === "error").length;
    return { problems, errorCount, warningCount: problems.length - errorCount, ok: errorCount === 0 };
  };

  const reader = new ZipReader(new BlobReader(source));
  let entries: Entry[];
  try {
    entries = await reader.getEntries();
  } catch (err) {
    add("error", "ZIP_UNREADABLE", "", "The file is not a readable zip: " + (err instanceof Error ? err.message : "unknown"));
    return finish();
  }

  try {
    const byName = new Map<string, Entry>();
    for (const e of entries) {
      if (!e.directory) byName.set(e.filename, e);
    }

    // 1. content types
    const defaults = new Map<string, string>();
    const overrides = new Map<string, string>();
    const ctEntry = byName.get("[Content_Types].xml");
    if (ctEntry === undefined) {
      add("error", "CONTENT_TYPES_MISSING", "[Content_Types].xml", "[Content_Types].xml is missing.");
    } else {
      const res = await parseXmlPart(ctEntry, maxXml, {
        open(local, uri, attrs): void {
          if (uri !== CT_NS) return;
          const type = attrs.find((a) => a.local === "ContentType")?.value;
          if (type === undefined) return;
          const ext = attrs.find((a) => a.local === "Extension")?.value;
          const part = attrs.find((a) => a.local === "PartName")?.value;
          if (local === "Default" && ext !== undefined) defaults.set(ext.toLowerCase(), type);
          if (local === "Override" && part !== undefined) overrides.set(part.replace(/^\//, ""), type);
        },
        close(): void {},
      });
      if (res.kind === "bad") add("error", res.code, "[Content_Types].xml", res.message);
      for (const name of byName.keys()) {
        if (name === "[Content_Types].xml") continue;
        const ext = name.includes(".") ? (name.split(".").pop() ?? "").toLowerCase() : "";
        if (!overrides.has(name) && !defaults.has(ext)) {
          add("error", "CONTENT_TYPE_MISSING", name, "This part has no content type.");
        }
      }
    }

    if (!byName.has("word/document.xml")) {
      add("error", "DOCUMENT_MISSING", "word/document.xml", "word/document.xml is missing.");
    }

    // 2. relationships
    const relsByPart = new Map<string, Map<string, Rel>>();
    for (const [name, entry] of byName) {
      if (!name.endsWith(".rels") || !(name.startsWith("_rels/") || name.includes("/_rels/"))) continue;
      const owner = ownerOfRels(name);
      const rels = new Map<string, Rel>();
      const res = await parseXmlPart(entry, maxXml, {
        open(local, uri, attrs): void {
          if (uri !== PKG_REL_NS || local !== "Relationship") return;
          const id = attrs.find((a) => a.local === "Id")?.value;
          const target = attrs.find((a) => a.local === "Target")?.value;
          if (id === undefined || target === undefined) return;
          const mode = attrs.find((a) => a.local === "TargetMode")?.value;
          rels.set(id, { id, target, external: mode === "External" });
        },
        close(): void {},
      });
      if (res.kind === "bad") {
        add("error", res.code, name, res.message);
        continue;
      }
      relsByPart.set(owner, rels);
      const base = dirOf(owner);
      for (const rel of rels.values()) {
        if (rel.external) continue;
        const resolved = resolveTarget(base, rel.target);
        if (resolved === null) {
          add("error", "REL_TARGET_UNSAFE", name, "Relationship " + rel.id + " points outside the package.");
        } else if (!byName.has(resolved)) {
          add("error", "REL_TARGET_MISSING", name, "Relationship " + rel.id + " points to a missing part: " + resolved);
        }
      }
    }

    // styles and numbering ids
    const styleIds = new Set<string>();
    const stylesEntry = byName.get("word/styles.xml");
    if (stylesEntry !== undefined) {
      const res = await parseXmlPart(stylesEntry, maxXml, {
        open(local, uri, attrs): void {
          if (uri !== W_NS || local !== "style") return;
          const id = attrs.find((a) => a.uri === W_NS && a.local === "styleId")?.value;
          if (id !== undefined) styleIds.add(id);
        },
        close(): void {},
      });
      if (res.kind === "bad") add("error", res.code, "word/styles.xml", res.message);
    }
    const numIdsDefined = new Set<string>();
    const numberingEntry = byName.get("word/numbering.xml");
    if (numberingEntry !== undefined) {
      const res = await parseXmlPart(numberingEntry, maxXml, {
        open(local, uri, attrs): void {
          if (uri !== W_NS || local !== "num") return;
          const id = attrs.find((a) => a.uri === W_NS && a.local === "numId")?.value;
          if (id !== undefined) numIdsDefined.add(id);
        },
        close(): void {},
      });
      if (res.kind === "bad") add("error", res.code, "word/numbering.xml", res.message);
    }

    // 3-7. content parts
    let stylesMissingReported = false;
    for (const [name, entry] of byName) {
      if (!CONTENT_PART.test(name)) continue;
      const { facts, callbacks } = createFactsCollector();
      const res = await parseXmlPart(entry, maxXml, callbacks);
      if (res.kind === "bad") {
        add("error", res.code, name, res.message);
        continue;
      }
      const rels = relsByPart.get(name);
      for (const id of facts.rIds) {
        if (rels === undefined || !rels.has(id)) {
          add("error", "REL_ID_UNRESOLVED", name, "Reference " + id + " has no matching relationship.");
        }
      }
      for (const id of facts.pStyles) {
        if (stylesEntry === undefined) {
          if (!stylesMissingReported) {
            add("warning", "STYLES_PART_MISSING", "word/styles.xml", "word/styles.xml is missing, so styles cannot be checked.");
            stylesMissingReported = true;
          }
        } else if (!styleIds.has(id)) {
          add("warning", "STYLE_MISSING", name, "Style " + id + " is not defined in styles.xml.");
        }
      }
      for (const msg of facts.sectProblems) {
        add("error", "SECTPR_MALFORMED", name, "Section properties: " + msg + ".");
      }
      for (const id of facts.numIds) {
        if (id !== "0" && !numIdsDefined.has(id)) {
          add("error", "NUMID_MISSING", name, "List number " + id + " is not defined in numbering.xml.");
        }
      }
      for (const id of facts.bookmarkDuplicates) {
        add("error", "BOOKMARK_DUPLICATE_ID", name, "Bookmark id " + id + " is used more than once.");
      }
    }
  } finally {
    await reader.close();
  }
  return finish();
}
