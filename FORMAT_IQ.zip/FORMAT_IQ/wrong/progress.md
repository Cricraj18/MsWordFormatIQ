# formatIQ progress

| File | Written | Tests pass | ChatGPT review | Checked in Word | Issues |
|---|---|---|---|---|---|
| 0a | | | | | |
| 0b | | | | | |
| 0c | | | | | |
| 0d | | | | | |
