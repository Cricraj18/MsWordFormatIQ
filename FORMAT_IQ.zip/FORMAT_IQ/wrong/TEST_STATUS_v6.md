# formatIQ TEST STATUS v6 (chat 10, sandbox: Linux, 4 GB RAM, 1 CPU; replaces TEST_STATUS_v5)

Method: rebuilt a comment-free types.ts (all exports), package.json, tsconfig.json, vite.config.ts in /home/claude/formatiq, wrote the new files, ran everything. Node 22.22.2 and Node 18.20.8 (see HANDOFF_v15 for how to get Node 18). zip.js 2.23.0, Vitest 2.1.9, TypeScript 5.9.x, Vite 5.4.x, sax 1.x.
NOT redone this chat (tested in chats 7 to 9): 22 zipio tests, 2 version tests, 12 xml tests, 27 template_extract tests, 56 paragraphs/structure tests. The numbers below count only the NEW tests of chat 10.

## TESTED (really run, chat 10)
- npm run typecheck: clean (strict, noUncheckedIndexedAccess, noUnused*), with xml_rewrite.ts, styles.ts and their tests. No "any" and no non-null "!" in the new code (searched).
- npm test on Node 22.22.2: 54 of 54 pass (32 xml_rewrite + 22 styles).
- npm test on Node 18.20.8: 54 of 54 pass.
- npm run build: ok with a temporary entry that imports each new file (xml_rewrite bundle 25 kB, 9 kB gzip; styles 1.6 kB). Same harmless sax "stream" warning. Entry restored afterwards.
- All 54 passed on the first run, no code fix was needed.
- xml_rewrite tests (32): escape helpers; getAttr/withAttr; XmlSerializer (<a/> for an immediately closed pair, held open tag flushed, dangling open flushed, empty text skipped); round trip without transform (prefixes, attribute order, namespace declarations, XML declaration, empty pair becomes self-closing, xml:space preserve text, five entities and numeric references, tab/newline in attributes, comments and processing instructions, CDATA becomes escaped text, accents/Japanese/emoji, one-character feeding gives the same result, output stable when rewritten again); transform (rename a style id, insert a child into an empty element, drop an element by tracking depth, emit extra tokens and raw xml, new text and attributes escaped, transform errors come out unchanged, emit nothing gives empty output); safety (DOCTYPE entity bomb, plain DOCTYPE, damaged XML with part name, unclosed document, undefined entity); streaming size (100000 paragraphs in 64 KB pieces, about 1.2 s).
- styles tests (22): normalizeStyleName; buildStyleMap (full template, own ids, localized name via id pattern, Figure/Table Caption over Caption, Normal before Body Text, Code and HTML Preformatted, non-paragraph styles ignored, empty template); headingStyleFor (exact, deeper than template, clamping, null cases); effectiveRole and styleIdForParagraph (manual wins, manual heading level, clamp, every role mapped, manual tag changes style, role without a style gives null); missingStyleNames (each once and sorted, empty when complete, list/code/body/quote names).

## NOT TESTED
1. Real browser: zip.js Web Workers, sax in a browser bundle, file picker, showSaveFilePicker, dev server page. Not possible here (headless browser download blocked; see TEST_STATUS_v3).
2. A true 1 GB docx (try about 900 MB if RAM allows; chat 6 did 600 MB: 5.9 s, peak RSS 1.4 GB).
3. zip.js passThrough option (raw copy).
4. Files saved by real Word, LibreOffice, Google Docs (detection rules, xml_rewrite and styles were only tried on hand-made data and one library-made file).
5. Half-written output after cancel on a real disk stream (needs browser).
6. Streaming a 200 MB document.xml through detection or xml_rewrite (only about 12 MB and 60000 to 100000 paragraphs tested).
7. UTF-16 encoded XML parts (we always decode UTF-8; Word writes UTF-8).
8. Lists set only by a style, numbering.xml, localized Word style names (only the id-pattern fallback is tested in styles.ts), font-based code detection (not implemented).
9. xml_rewrite on a zip part end to end (glue with zipio is built in 3b), and the paragraph index match between apply and readParagraphs (a 3b test is required).
10. Everything from 3b (apply.ts) onward (not built yet).
