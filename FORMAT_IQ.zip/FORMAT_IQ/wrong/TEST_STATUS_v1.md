# formatIQ TEST STATUS v1 (chat 6, sandbox: Linux, 4 GB RAM, 1 CPU)

Method: rebuilt the WHOLE project from Drive text (package.json, tsconfig, vite.config.ts, index.html, src/version.ts, main.ts, version.test.ts, FULL types.ts, zipio.ts, zipio.test.ts; comments left out of code copies). Real Node 22.22.2 and Node 18.20.8 (npm i node@18 in /tmp works). zip.js 2.23.0, Vitest 2.1.9, TypeScript 5.9.3, Vite 5.4.21.

## TESTED (really run)
- npm run typecheck (strict, noUncheckedIndexedAccess, noUnused*, types: vite/client): clean.
- npm test on Node 22: 17 of 17 pass (15 zipio + 2 version).
- npm test on Node 18.20.8: 17 of 17 pass. Node 18 has no "deflate-raw" CompressionStream; zip.js falls back; no change needed.
- npm run build (tsc + vite build): ok, dist/index.html + one 0.83 kB js.
- Full types.ts typechecks (no longer a trimmed copy).
- LARGE FILE: 600 MB docx (30 parts x 20 MB, stored): openDocx 0.01 s, copy + write 5.9 s, output 600 MB, peak RSS 1.4 GB (source and output both held as Blobs in Node). Output opens, document.xml replaced correctly. Not 1 GB (RAM too small to do it safely).
- M1 RESOLVED: central directory said 10 bytes, real part 5000. zip.js 2.23.0 throws "Invalid uncompressed size" on read AND in copyEntry. So no extra size check is needed. DROP M1.
- M2 CORRECTED: "signal" is NOT a valid option of getEntries (tsc error TS2353) and an aborted signal is ignored. The fix in REVIEW_v1 (pass signalOptions to getEntries) is WRONG. Right fix: add control?: JobControl to openDocx; check control.signal.aborted before and after getEntries() and map it with mapError(err, control, ...). getEntries itself cannot be cancelled (it only reads the index, so it is short).
- M3 CONFIRMED by test: DEFAULT_FORMAT_OPTIONS.parts.push("toc") changes the shared default.
- L1 CONFIRMED: createJobControl(2**31+10) aborts within 50 ms on Node 22 and Node 18.
- L2 CONFIRMED earlier: "a//b.xml" passes zip.js and isSafeZipPath.
- L3: non-zip file gives "File format is not recognized".
- L6 CONFIRMED earlier: zip.js rejects "../x" on read ("Unsafe filename"), allows it on write.
- L7 TESTED: cancel in the middle of copyEntry gives CANCELLED; finish() afterwards returns without error (no crash). Whether the output zip is valid after a cancel is not checked, and the output is thrown away anyway.
- T2 TESTED: ZipWriter output chunks are separate buffers (8 chunks, 8 ArrayBuffers) and unchanged after write. The "copy at the end" test pattern is safe in 2.23.0. Copy at write time is still the safer style.
- T1 DROPPED (Node 18 ok).

## NOT TESTED (left for the next chat)
1. Apply the fixes (HANDOFF_v8 step A) and re-run everything on Node 22 AND Node 18.
2. A real browser: zip.js Web Workers (useWebWorkers true), file picker, showSaveFilePicker streaming to disk, the dev server page showing "formatIQ v0.0.1". Needs the user (or a headless browser if one can be installed: UNSURE).
3. A true 1 GB docx. Try ~900 MB only if RAM allows; otherwise leave for the office.
4. The "passThrough" zip.js option (raw copy without recompressing) was never tried. Idea only.
5. Real Word-made .docx files (the tests only use tiny hand-made zips). Ask the user for one sample .docx, or build one with a library if the sandbox allows.
6. Tests for the new code in step A (aborted control in openDocx, "a//b", createDefaultFormatOptions).
7. Whether a cancelled/partial output zip leaves a half-written file when streaming to a real disk stream (L7 decision, needs browser).
8. Tests were typechecked together with the code; the probe files used in this chat (probe.test.ts, big.test.ts) are NOT saved in Drive and not part of the project.
