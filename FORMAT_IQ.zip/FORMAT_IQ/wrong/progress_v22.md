formatIQ progress v22 (chat 17)
DONE: v28 NEXT 1. watermark.ts v2 (imports shared types from ../types and re-exports them) is saved in Drive src/core (17909 bytes, id 1VFty_ZiM-_bH_WLK-dl07t_Wp_b3lG9A), old file in "wrong" as watermark_OLD_v28.ts. Tested in chat 17: 35 of 35 on Node 22 and Node 18, typecheck clean, build ok.
NEXT: v28 NEXT 2 (FormatOptions fields required if apply.test.ts allows), 3 (wire page_setup and watermark into apply.ts), 4 (3c, 5a, captions, toc), 5 (validateDocx run, whole suite). See HANDOFF_v29.
