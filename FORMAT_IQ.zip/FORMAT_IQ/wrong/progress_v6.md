# formatIQ progress v6

| File | Written | Tested in sandbox | Review | Issues |
|---|---|---|---|---|
| 0a setup | yes | typecheck, build ok | n/a | none |
| 0b types.ts | yes | typecheck | REVIEW_v1 | M3: shared mutable parts array in DEFAULT_FORMAT_OPTIONS |
| 0c zipio read | yes | 15 tests (Node 22) | REVIEW_v1 | M2 timeout/cancel missing in openDocx |
| 0d zipio write | yes | same | REVIEW_v1 | M1 no size check in copyEntry; T1 Node 18 UNSURE |

Not tested: Node 18, real browser (Web Workers, file picker), real 1 GB file.
Next: HANDOFF_v7.md step A (apply review fixes), then 1a template_extract.ts.
Outdated files still in root (move to "wrong" by hand): HANDOFF_v5.md, progress_v4.md.
