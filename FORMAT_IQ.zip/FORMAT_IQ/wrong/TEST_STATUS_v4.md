# formatIQ TEST STATUS v4 (chat 9, sandbox: Linux, 4 GB RAM, 1 CPU; replaces TEST_STATUS_v3)

Method: rebuilt types.ts, zipio.ts and xml.ts in /home/claude/formatiq from the Drive text (comments left out, code the same), wrote the new files, ran everything. Node 22.22.2 and Node 18.20.8 (see HANDOFF_v13 for how to get Node 18). zip.js 2.23.0, Vitest 2.1.9, TypeScript 5.9.3, Vite 5.4.x, sax 1.6.x, docx 9.10.x.
NOT redone this chat (tested in chats 7 and 8): the 22 zipio tests, 2 version tests, 12 xml tests, 27 template_extract tests. The numbers below count only the NEW tests of chat 9.

## TESTED (really run, chat 9)
- npm run typecheck: clean (strict, noUncheckedIndexedAccess, noUnused*), with the new files. No "any" and no non-null "!" in the new code (searched).
- npm test on Node 22.22.2: 56 of 56 pass (18 paragraphs.test.ts + 24 structure_rules.test.ts + 14 structure_detect.test.ts).
- npm test on Node 18.20.8: 56 of 56 pass.
- npm run build: ok with a temporary entry that imports structure_detect (bundle 164 kB, 71 kB gzip). Same harmless sax "stream" warning as before. Entry restored afterwards.
- First run: 2 rule tests failed (Annexure/Appendix did not match capital letters; the regex had no "i" flag). Fixed in structure_rules.ts, rerun green. The Drive copy has the fix.
- paragraphs tests: text, index, style; empty and self-closing paragraphs; tables incl. nested; numId 0 is not a list; outline level (0 based XML to 1 based, 9 = none); drawing and pict; deleted text and field codes ignored, tab and break; tab stops in pPr ignored; text-box paragraphs skipped; 300-character cut; bold states (all, none, mixed, off, whitespace run, paragraph-mark bold ignored); font size (biggest run with text); other namespace prefix; one-character-at-a-time feeding with accents, Japanese, emoji; 100000 paragraphs streamed (about 1 s); style hints incl. docDefaults, basedOn, loops, duplicate ids, missing names, non-paragraph styles skipped.
- structure_rules tests: numbered headings (levels, confidence, rejects sentences, years, plain numbers, non-Latin), labeled headings, captions, roleFromStyle, helpers, and classifyParagraph for every rule in order.
- structure_detect tests: a mixed small document (title, chapter, 1.1, body, figure caption, list, table, table caption, empty, Annexure), low-confidence counting, body size by characters, no styles.xml, heading style, streaming plus progress order, source blob unchanged, errors (NOT_DOCX, DOCTYPE bomb -> XML_ENTITY_EXPANSION, damaged XML -> ZIP_READ_FAILED, already cancelled -> CANCELLED, byte cap -> XML_TOO_LARGE or FILE_TOO_LARGE), a real-style file made by the "docx" npm package (Title, Heading 1/2, bullet list, table, caption, bold numbered line), and 60000 paragraphs streamed in order (about 2.5 s for both passes, 600 headings found).

## NOT TESTED
1. Real browser: zip.js Web Workers, sax in a browser bundle, file picker, showSaveFilePicker, dev server page. Not possible here (headless browser download blocked; see TEST_STATUS_v3).
2. A true 1 GB docx (try about 900 MB if RAM allows; chat 6 did 600 MB: 5.9 s, peak RSS 1.4 GB).
3. zip.js passThrough option (raw copy).
4. Files saved by real Word, LibreOffice, Google Docs. Detection rules were tuned only on hand-made XML and one library-made file, so real-world accuracy is unknown.
5. Half-written output after cancel on a real disk stream (needs browser).
6. Streaming a 200 MB document.xml (only about 12 MB and 60000 paragraphs tested; speed estimate 15 MB/s per pass).
7. UTF-16 encoded XML parts (we always decode UTF-8; Word writes UTF-8).
8. Lists set only by a style, numbering.xml, localized Word style names, font-based code detection (not implemented).
9. Everything from file 3a onward (not built yet).
