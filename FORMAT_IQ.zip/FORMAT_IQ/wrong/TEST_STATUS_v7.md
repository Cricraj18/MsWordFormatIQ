# formatIQ TEST STATUS v7 (chat 10, sandbox: Linux, 4 GB RAM, 1 CPU; replaces TEST_STATUS_v6)

Method: comment-free full types.ts, package.json, tsconfig.json, vite.config.ts in /home/claude/formatiq. New files written and run. Node 22.22.2 and Node 18.20.8. zip.js 2.23.0, Vitest 2.1.9, TypeScript 5.9.x, Vite 5.4.x, sax 1.x.
NOT redone this chat (tested in chats 7 to 9): 22 zipio tests, 2 version tests, 12 xml tests, 27 template_extract tests, 56 paragraphs/structure tests. Counts below are NEW tests of chat 10 only.

## TESTED (really run, chat 10)
- npm run typecheck: clean (strict, noUncheckedIndexedAccess, noUnused*) with xml_rewrite.ts, styles.ts, restyle.ts and tests. No "any" and no non-null "!" in the new code (searched). No non-ASCII characters in restyle files (searched).
- npm test on Node 22.22.2: all pass. Files run together in the last full run: 75 tests (xml_rewrite 32, styles 22, restyle 21).
- npm test on Node 18.20.8: the same 75 pass.
- npm run build: ok with a temporary entry for each new file (restyle bundle 25 kB, 9 kB gzip, which includes xml_rewrite and sax). Entry restored afterwards.
- One test expectation was wrong in restyle.test.ts (counted 9 cleared run properties, the correct number is 8: 2 on the paragraph mark, 6 on the run). The code was right; the test was corrected, rerun and saved.
- restyle tests (21): setting the style (new pPr, replace old pStyle and put it first, add pStyle first in an existing pPr, empty self-closing paragraph, whitespace before pPr, section break kept after pStyle, odd characters in the style id, same prefix as the document, stable when run twice); leaving paragraphs alone (null style copies exactly, only some changed); clearing (removes the listed paragraph and run properties with exact counts, keeps list/layout/emphasis/language parts, keep mode changes only the style, tracked formatting change records untouched, paragraphs left alone keep their formatting); numbering (text-box paragraphs not counted or changed, table and content-control paragraphs counted); parity with the real paragraph reader code (documents with title, empty paragraphs, nested tables, text boxes inside drawings, content control, list item, section break: every paragraph gets the style made for its own number; text, inTable and isListItem read back unchanged; output re-parses); streaming (100000 paragraphs in 64 KB pieces, all counters exact, about 1.4 s).

## IMPORTANT CAVEAT ABOUT THE PARITY TEST
restyle.test.ts imports ./xml and ./paragraphs. In the sandbox these were a comment-free copy of xml.ts and a PARTIAL copy of paragraphs.ts (only createParagraphHandlers, text copied from the Drive file) plus a stub zipio.ts. They were not saved. The Drive paragraphs.ts, xml.ts and zipio.ts were therefore not run together with restyle in this chat. The logic tested is the same code, but a first job of the next chat is to run restyle.test.ts against the REAL Drive files once zipio.ts is rebuilt for apply.ts.

## NOT TESTED
1. Real browser: zip.js Web Workers, sax in a browser bundle, file picker, showSaveFilePicker, dev server page (headless browser download blocked, see TEST_STATUS_v3).
2. A true 1 GB docx (try about 900 MB if RAM allows; chat 6 did 600 MB: 5.9 s, peak RSS 1.4 GB).
3. zip.js passThrough option (raw copy).
4. Files saved by real Word, LibreOffice, Google Docs (everything so far uses hand-made XML or one library-made file).
5. Half-written output after cancel on a real disk stream (needs browser).
6. A 200 MB document.xml through detection, xml_rewrite or restyle (about 12 MB and 100000 paragraphs tested).
7. UTF-16 encoded XML parts (we always decode UTF-8).
8. Lists set only by a style, numbering.xml, localized Word style names, font-based code detection.
9. restyle on a real zip part end to end, template package merge, numbering merge, relationships and content types, validate (apply.ts not built).
10. Page setup, header/footer inheritance, watermark, sections, captions, cross-references, TOC, tables, images, notes, report, UI, template store, image reduction, batch (HANDOFF_v16 and v17 items, not built).
