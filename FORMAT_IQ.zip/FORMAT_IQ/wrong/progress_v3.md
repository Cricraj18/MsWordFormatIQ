# formatIQ progress v3

| File | Written | Tests pass | ChatGPT review | Checked in Word | Issues |
|---|---|---|---|---|---|
| 0a setup | yes | not run yet | not needed | n/a | package versions UNSURE |
| 0b types.ts | yes | not run yet | | n/a | no test file yet; tsconfig target vs Object.setPrototypeOf UNSURE (harmless) |
| 0c zipio read | | | | | |
| 0d zipio write | | | | | |

User to-do for 0a and 0b (at the office): install Node.js (LTS), open a terminal in the project folder, run: npm install, npm run typecheck, npm test, npm run dev. Report results. Make sure src/types.ts is in the src folder next to main.ts.
