# progress v25 (2026-10-18)
- Decision: progress lives in Google Drive only, no git repo.
- No zip attached this chat: no code imported, built or tested.
- Clean-up: progress_v23.md moved to "wrong"; progress_v24.md moved to "wrong" (this file is now the highest).
- Saved HANDOFF_v33.md (self-contained), progress_v25.md, TEST_STATUS_v20.md.
- Next: attach FORMAT_IQ.zip, then follow HANDOFF_v33 REMAINS item 1 (typecheck apply.ts).
