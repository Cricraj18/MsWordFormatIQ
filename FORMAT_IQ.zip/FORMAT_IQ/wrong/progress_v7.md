# formatIQ progress v7 (chat 7)

DONE so far
- 0a package.json, tsconfig, Vite, Vitest setup (tested in sandbox)
- 0b src/types.ts (tested; createDefaultFormatOptions replaces DEFAULT_FORMAT_OPTIONS)
- 0c/0d src/core/zipio.ts + zipio.test.ts (step A fixes applied; 24/24 tests on Node 22 and Node 18, build ok)

SAVED IN DRIVE (chat 7): types.ts (src), zipio.ts and zipio.test.ts (src/core), TEST_STATUS_v2.md, HANDOFF_v11.md. Old copies are in "wrong" as types_OLD_v2.ts, zipio_OLD_v2.ts, zipio.test_OLD_v2.ts.

NEXT: step B (sandbox probes), then file 1a template_extract.ts and 1b its tests.
