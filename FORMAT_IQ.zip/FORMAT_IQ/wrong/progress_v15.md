# formatIQ progress v15 (chat 11)

DONE this chat
- Read HANDOFF_v20 and everything its READ ORDER names (v6, v8, v9, v15 to v19, TEST_STATUS_v9, REVIEW_v1, REVIEW_v1_addendum).
- Clean-up: nothing in root, src or src/core was outdated or broken. Consolidation done: HANDOFF_v21.md (self-contained). Moved to "wrong": HANDOFF_v6, v8, v9, v15, v16, v17, v18, v19, v20.
- Built and saved step 3b-3: numbering_merge.ts + numbering_merge.test.ts (29 tests, Node 22 and Node 18, typecheck clean, build ok).
- Saved HANDOFF_v22.md, TEST_STATUS_v10.md, this file.

NEXT
- validate.ts, then apply.ts (HANDOFF_v21 section 7), then 3c, 5a, 5b, 5c and the rest of the feature register.

NOTES
- Drive ids must be copied with every character (package.json id ends with an underscore).
- The sandbox cannot reach Drive; code is copied in by hand from read_file_content or download_file_content, so keep sandbox and Drive sizes equal after saving.
