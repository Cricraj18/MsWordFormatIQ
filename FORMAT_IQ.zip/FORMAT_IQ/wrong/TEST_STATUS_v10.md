# formatIQ TEST STATUS v10 (chat 11; replaces TEST_STATUS_v9; read with HANDOFF_v21 and v22)

Method: sandbox (Linux, 4 GB RAM, 1 CPU). Comment-free copies of types.ts and xml_rewrite.ts (same behaviour as Drive), package.json/tsconfig/vite config rebuilt from HANDOFF_v21 facts (Drive package.json read fine: id ends with an underscore, 12UPCa6XlmDe2K4I1tSMljv7Ag3hyy8J_; build script there is "tsc --noEmit && vite build"). Node 22.22.2 and Node 18.20.8. Vitest 2.1.9, TypeScript 5.9.x, Vite 5.4.x, sax 1.x, zip.js 2.23.0 (installed, not used by this chat's file).

## TESTED (really run, chat 11)
- src/core/numbering_merge.ts (13620 bytes) + numbering_merge.test.ts (10292 bytes): 29 of 29 tests pass on Node 22.22.2 AND Node 18.20.8; typecheck clean (strict, noUncheckedIndexedAccess, noUnused*); npm run build ok with a temporary entry (bundle 29.7 kB, 10.8 kB gzip; entry restored); no "any", no non-null "!", no non-ASCII characters (searched). Drive copies have the same byte sizes as the sandbox copies.
- One test expectation was wrong and was fixed before saving (a substring check matched "TplHeading1"); the code was right.
- Coverage: parseNumbering (split root and children, ids, picture bullets and other children, escaped attributes kept, empty root, damaged XML, DOCTYPE, listNumIds); mergeNumbering (neither side, template only, id shifts and abstractNumId update, template children byte for byte, source lvlOverride kept, source list-level pStyle links removed with warning and template links kept, picture bullet shift + lvlPicBulletId, no template numbering (shift 0), high template ids, numIdMacAtCleanup rule, namespace and mc:Ignorable union, namespace conflict warning, style-link warning, deterministic and inputs untouched, unique ids and clean re-parse, empty source, damaged source); numId remap (mapped, 0 kept, unmapped counted, pPrChange numPr, other elements and the w:num attribute untouched, empty map, chained transform, other prefix, single shift).
- Earlier chats (NOT redone, still valid): zipio v2 28, package_merge 36, restyle 21, xml_rewrite 32, styles 22 (139 tests in chat 10); xml 12, template_extract 27, paragraphs/structure 56 (chats 7 to 9). The full Drive suite was NOT rerun together in chat 11 (the sandbox held only the files this chat needed).

## CAVEATS (open)
1. restyle.test.ts still needs a run against the real Drive paragraphs.ts and xml.ts (done together when apply.ts is built).
2. numbering_merge was tested on hand-made numbering XML, not on the numbering.xml of a real Word file.
3. Source list definitions that use w:styleLink / w:numStyleLink only produce a warning; they may not resolve.
4. When the template has no numbering part but the source has one, apply.ts must add a word/numbering.xml part, a relationship and a content-type Override (mergeNumbering gives the merged text with shift 0).

## NOT TESTED
1. Real browser (zip.js Web Workers, sax in a browser bundle, file picker, showSaveFilePicker, dev server page): headless browser download blocked.
2. A true 1 GB docx (600 MB tested in chat 6); addBlob parts over 20 MB; zip.js passThrough.
3. Files saved by real Word, LibreOffice, Google Docs.
4. Cancel mid-write on a real disk stream (needs a browser); UTF-16 XML parts; 200 MB document.xml.
5. Lists set only by a style, localized style names, font-based code detection.
6. validate.ts, apply.ts (not built yet); page setup, header/footer inheritance, watermark, sections, captions, cross-references, TOC, tables, images, notes, report, UI, template store, image reduction, batch (not built).
