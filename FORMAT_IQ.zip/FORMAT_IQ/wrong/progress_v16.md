# formatIQ progress v16 (chat 11)

DONE this chat
- Read HANDOFF_v20 and everything its READ ORDER names. Clean-up and consolidation: HANDOFF_v21.md (self-contained). Moved to "wrong": HANDOFF_v6, v8, v9, v15 to v20, TEST_STATUS_v9, progress_v14, and (after this save) HANDOFF_v22, TEST_STATUS_v10, progress_v15.
- Built, tested (Node 22 and 18, typecheck, build) and saved: numbering_merge.ts + test (29 tests), validate.ts + test (21 tests).
- Saved HANDOFF_v23.md, TEST_STATUS_v11.md, this file.

NEXT
- apply.ts (HANDOFF_v21 section 7, HANDOFF_v23 notes), then 3c, 5a, 5b, 5c, 4a/4b, toc, rest of the feature register.

NOTES
- Drive ids must be copied with every character.
- The sandbox cannot reach Drive; code is copied by hand, keep sandbox and Drive sizes equal.
