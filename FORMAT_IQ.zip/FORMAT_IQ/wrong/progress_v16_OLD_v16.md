# formatIQ progress v16 (chat 12)

DONE this chat
- Read HANDOFF_v22, v21, TEST_STATUS_v10, progress_v15 and searched root, src, src/core, wrong (REVIEW files not reopened: history only).
- Clean-up: nothing in root, src or src/core was outdated or broken (all code sizes match HANDOFF_v21). After saving the v23/v11/v16 files, moved progress_v15 and TEST_STATUS_v10 to "wrong". HANDOFF_v21 and HANDOFF_v22 stay (v23 is a short update on top of them).
- Built and saved step 3b-4: validate.ts + validate.test.ts (25 tests, Node 22 and Node 18, typecheck clean, build ok).
- Saved HANDOFF_v23.md, TEST_STATUS_v11.md, this file.
- Earlier history carried from progress_v15 (chat 11): consolidated HANDOFF_v21; built numbering_merge.ts + test (29 tests); moved old handoffs v6, v8, v9, v15 to v20 to "wrong".

NEXT
- apply.ts (HANDOFF_v21 section 7), then 3c, 5a, 5b, 5c and the rest of the feature register.
- apply.ts needs real Drive files in the sandbox: see LESSON in HANDOFF_v23 (copy base64 in small chunks, check sizes, typecheck, run the existing tests as a copy check).

NOTES
- Drive ids must be copied with every character (package.json id ends with an underscore).
- The sandbox cannot reach Drive. Never pad or invent the end of a copied file.
