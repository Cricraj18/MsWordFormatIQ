# formatIQ progress v21 (chat 16)
- Read HANDOFF_v21, v23 to v27 and TEST_STATUS_v12 to v15. Clean-up check: nothing to move.
- page_setup.ts v2 built, tested (39/39, Node 22 + 18, typecheck, build) and saved in Drive src/core. Old file is in "wrong" as page_setup_OLD_v27.ts.
- Next: watermark.ts types move, then wire page_setup + watermark into apply.ts.
