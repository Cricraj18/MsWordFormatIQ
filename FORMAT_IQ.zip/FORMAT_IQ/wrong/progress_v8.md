# formatIQ progress v8 (chat 8)

| File | Written | Tests (sandbox) | ChatGPT review | Checked in real Word | Issues |
|---|---|---|---|---|---|
| 0a setup | yes | typecheck + build ok (Node 22) | not needed | n/a | package.json now has sax, @types/sax, docx |
| 0b types.ts | yes | typecheck clean | no | n/a | none |
| 0c/0d zipio.ts + test | yes | 22 tests pass (chat 7, Node 22 + 18) | review v1 applied | n/a | not browser-tested |
| 1a-1 xml.ts (NEW) | yes | 12 tests pass (Node 22 + 18) | no | n/a | uses ZIP_READ_FAILED for damaged XML; sax "stream" build warning |
| 1a-2 template_extract.ts (NEW) | yes | 27 tests pass (Node 22 + 18) | no | n/a | only library-made .docx tried |
| 1b tests | yes (xml.test.ts, template_extract.test.ts) | 39 of 39 pass | no | n/a | |
| 2a structure_detect.ts | NEXT | | | | |

Totals new this chat: 39 tests. All run by Claude in the sandbox. The user was not asked to run anything.
