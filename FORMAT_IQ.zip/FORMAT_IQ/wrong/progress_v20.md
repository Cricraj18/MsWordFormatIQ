# formatIQ progress v20 (chat 15)

Chat 15 did: read HANDOFF_v26 and everything it names; clean-up search of all four folders (nothing to move); rebuilt the sandbox (project, Node 22, Node 18); wrote types.ts version 2 (page setup, watermark, keepSourceHeaders added to FormatOptions as optional fields) with 9 tests; tested on Node 22 and 18, typecheck and build ok; saved types.ts and types.test.ts to Drive src, moved the old types.ts to "wrong" as types_OLD_v26.ts; wrote HANDOFF_v27, TEST_STATUS_v15, progress_v20.

Done so far (whole project): config, types v2, zipio v2, xml, template_extract, paragraphs, structure_rules, structure_detect, xml_rewrite, styles, restyle, package_merge, numbering_merge, validate, page_setup, apply + apply_sections, watermark.

Not done: wire page_setup and watermark into apply.ts, finish moving the types out of page_setup.ts and watermark.ts, 3c partial apply, 5a header/footer choices, captions and cross-references, toc, tables, images, report, UI, template store, image reduction, batch, deploy guide.

Next chat: see HANDOFF_v27 NEXT.
