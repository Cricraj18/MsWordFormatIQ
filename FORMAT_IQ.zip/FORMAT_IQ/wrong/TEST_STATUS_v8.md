# formatIQ TEST STATUS v8 (chat 10, sandbox: Linux, 4 GB RAM, 1 CPU; replaces TEST_STATUS_v7)

Method: comment-free full types.ts, package.json, tsconfig.json, vite.config.ts in /home/claude/formatiq. Real zipio.ts v2 (written in full in the sandbox), comment-free xml.ts, PARTIAL paragraphs.ts (createParagraphHandlers only, copied from Drive). Node 22.22.2 and Node 18.20.8. zip.js 2.23.0, Vitest 2.1.9, TypeScript 5.9.x, Vite 5.4.x, sax 1.x.
NOT redone this chat (tested in chats 7 to 9): 12 xml tests, 27 template_extract tests, 56 paragraphs/structure tests. New or changed tests of chat 10 are listed below.

## TESTED (really run, chat 10)
- npm run typecheck: clean (strict, noUncheckedIndexedAccess, noUnused*) with xml_rewrite.ts, styles.ts, restyle.ts, zipio.ts v2 and all their tests. No "any" and no non-null "!" in the new code (searched). No non-ASCII characters in zipio.ts v2, zipio.test.ts or restyle files (searched; the test uses \u escapes for accents and Japanese).
- npm test on Node 22.22.2: 103 of 103 pass in 4 files (zipio 28, restyle 21, xml_rewrite 32, styles 22).
- npm test on Node 18.20.8: the same 103 pass.
- npm run build: ok with a temporary entry for zipio (bundle 169 kB, 72 kB gzip, includes zip.js). Entry restored afterwards.
- zipio v2: all 22 old tests pass unchanged against the new code (no regression). 6 new tests (addBlob): Blob of text pieces with accents and Japanese; 20 MB part written and read back with the same size (about 4 s); image name stored and bytes kept; unsafe paths refused; CANCELLED when already aborted; works with a WritableStream target.
- xml_rewrite 32, styles 22, restyle 21: as in TEST_STATUS_v7 (restyle now ran against the real zipio.ts).

## CAVEAT (still open)
restyle.test.ts imports ./xml and ./paragraphs. In the sandbox paragraphs.ts was a PARTIAL copy (createParagraphHandlers only, text from Drive) and xml.ts a comment-free copy. Run restyle.test.ts against the real Drive paragraphs.ts and xml.ts when they are rebuilt.

## NOT TESTED
1. Real browser: zip.js Web Workers, sax in a browser bundle, file picker, showSaveFilePicker, dev server page (headless browser download blocked, see TEST_STATUS_v3).
2. A true 1 GB docx (try about 900 MB if RAM allows; chat 6 did 600 MB: 5.9 s, peak RSS 1.4 GB). addBlob with parts over 20 MB is also untested (20 MB works).
3. zip.js passThrough option (raw copy).
4. Files saved by real Word, LibreOffice, Google Docs (everything so far uses hand-made XML or one library-made file).
5. Half-written output after cancel on a real disk stream (needs browser).
6. A 200 MB document.xml through detection, xml_rewrite or restyle (about 12 MB and 100000 paragraphs tested).
7. UTF-16 encoded XML parts (we always decode UTF-8).
8. Lists set only by a style, numbering.xml, localized Word style names, font-based code detection.
9. Package merge, numbering merge, apply.ts, validate.ts (not built yet; design in HANDOFF_v19).
10. Page setup, header/footer inheritance, watermark, sections, captions, cross-references, TOC, tables, images, notes, report, UI, template store, image reduction, batch (HANDOFF_v16 and v17 items, not built).
