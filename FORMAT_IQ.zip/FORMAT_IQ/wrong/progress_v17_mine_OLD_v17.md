# formatIQ progress v17 (chat 13)

DONE this chat
- Read HANDOFF_v23, v21, v22, TEST_STATUS_v11 and searched root, src, src/core, wrong (REVIEW files not reopened: history only; progress_v16 read).
- Clean-up: nothing in root, src or src/core was outdated or broken (all code sizes match HANDOFF_v21, v22, v23). After saving the v24/v12/v17 files, moved progress_v16 and TEST_STATUS_v11 to "wrong". HANDOFF_v21, v22 and v23 stay (v24 is a short update on top of them).
- Rebuilt the sandbox project and the 14 dependency files (comment-free copies via read_file_content), all typecheck clean.
- Built and saved step 3b-4: apply.ts + apply_sections.ts + apply.test.ts + apply_sections.test.ts (32 tests, Node 22 and Node 18, typecheck clean, build ok). Step 3b is complete.
- Saved HANDOFF_v24.md, TEST_STATUS_v12.md, this file.
- Earlier history carried from progress_v16 (chat 12): built validate.ts + validate.test.ts (25 tests). From chat 11: consolidated HANDOFF_v21; numbering_merge.ts + test (29 tests); moved old handoffs v6, v8, v9, v15 to v20 to "wrong".

NEXT
- 3c partial apply (scope "selected"), 5a headers/footers, 5b page_setup + sections (types.ts growth), 5c watermark, 4a-4b captions + cross-references, toc.ts, rest of the feature register (HANDOFF_v21 section 6).
- Small: a test that runs validateDocx on an apply output; run the whole Drive suite together once.

NOTES
- Drive ids must be copied with every character (package.json id ends with an underscore).
- The sandbox cannot reach Drive; copy code with read_file_content (see HANDOFF_v24 rebuild section). Check every saved file's size against the sandbox size.
