# formatIQ TEST STATUS v3 (chat 8, sandbox: Linux, 4 GB RAM, 1 CPU; replaces TEST_STATUS_v2)

Method: rebuilt types.ts and zipio.ts in /home/claude/formatiq from Drive text (comments left out, code the same), added the new files, ran everything. Node 22.22.2 and Node 18.20.8 (mkdir /tmp/n18; cd /tmp/n18; npm init -y; npm i node@18; run: /tmp/n18/node_modules/node/bin/node node_modules/vitest/vitest.mjs run). zip.js 2.23.0, Vitest 2.1.9, TypeScript 5.9.3, Vite 5.4.21, sax 1.6.x, docx 9.10.x.
NOT redone this chat (tested in chat 7, Drive file sizes match the handoff: types.ts 7947, zipio.ts 13382, zipio.test.ts 10874): the 22 zipio tests and the 2 version tests. So the numbers below count only the NEW tests.

## TESTED (really run, chat 8)
- npm run typecheck: clean (strict, noUncheckedIndexedAccess, noUnused*), with the new files.
- npm test on Node 22.22.2: 39 of 39 pass (12 xml.test.ts + 27 template_extract.test.ts).
- npm test on Node 18.20.8: 39 of 39 pass.
- npm run build: ok. With a temporary entry that imports template_extract the bundle is 157 kB (69 kB gzip). Vite prints a harmless warning: sax asks for the Node module "stream" (sax wraps it in try/catch, so the browser build is fine in principle; real browser NOT tested). Entry was restored afterwards.
- sax probes (real): a DOCTYPE with nested entities is NOT expanded (the text stays "&b;" and sax reports "Invalid character entity"); the 5 built-in and numeric entities work; unknown entity is an error. Speed about 15 MB/s (20 MB XML in 1.3 s), so a 200 MB document.xml is about 13 s.
- xml.ts tests: prefix removal, one-character-at-a-time feeding gives identical results, CDATA, entities, DOCTYPE bomb -> XML_ENTITY_EXPANSION (also when it comes through the zip stream), unknown entity and unclosed XML -> error, multi-byte text (accents, Japanese, emoji) across chunks, 100000-paragraph (12 MB) file streamed, byte cap -> FILE_TOO_LARGE, damaged XML -> ZIP_READ_FAILED with the part name.
- template_extract tests: style kinds and names, unknown style types skipped, duplicate ids keep the first, other namespace prefix, missing styles.xml -> TEMPLATE_INVALID, empty styles; page setup: A4 default, Letter, landscape by orient, FIRST sectPr wins, pgSz inside sectPrChange ignored, bad numbers -> A4; header/footer parts; TOC as instrText, as fldSimple, as content control, "TOCX" and PAGE are not TOC; wrong extension -> NOT_DOCX; non-zip text -> ZIP_READ_FAILED; DOCTYPE bomb in styles.xml and in document.xml -> XML_ENTITY_EXPANSION; damaged XML; already-cancelled job -> CANCELLED; progress goes 0 -> 1 in order; source blob unchanged; 60000-paragraph document read in about 0.3 s.
- A real-style .docx made by the "docx" npm package (headings, TOC, header, footer, landscape) is read correctly by openDocx + extractTemplateInfo. This covers the old "real-style .docx" item, but only for a file made by a library, NOT for files saved by real Word, LibreOffice or Google Docs.
- Headless browser attempt (HANDOFF_v9 rule 4): npm i playwright works, but "playwright install chromium" fails: the download is blocked by the sandbox network (only npm, pypi, github and a few hosts are allowed). Result: browser: not testable here.

## NOT TESTED
1. Real browser: zip.js Web Workers, sax in a browser bundle, file picker, showSaveFilePicker, dev server page ("formatIQ v0.0.1"). Cannot be done here (see above).
2. A true 1 GB docx (try about 900 MB if RAM allows; chat 6 did 600 MB: 5.9 s, peak RSS 1.4 GB). Not tried in chat 8.
3. zip.js passThrough option (raw copy). Not tried.
4. Files saved by real Word, LibreOffice, Google Docs (only a library-made file and hand-made XML were used).
5. Half-written output after cancel on a real disk stream (needs browser).
6. Streaming a 200 MB document.xml through sax inside the sandbox (only 12 MB tested; speed estimate from the 20 MB probe).
7. UTF-16 encoded XML parts (we always decode UTF-8; Word writes UTF-8).
8. Everything from file 2a onward (not built yet).
