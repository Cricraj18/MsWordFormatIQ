# formatIQ TEST STATUS v11 (chat 11; replaces TEST_STATUS_v10; read with HANDOFF_v21 and v23)

Method: sandbox (Linux, 4 GB RAM, 1 CPU). Comment-free copies of types.ts and xml_rewrite.ts, and a subset of package_merge.ts (same code, only the functions validate.ts uses). Node 22.22.2 and Node 18.20.8. Vitest 2.1.9, TypeScript 5.9.x, Vite 5.4.x, sax 1.x, zip.js 2.23.0, docx npm package (test fixtures).

## TESTED (really run, chat 11)
- numbering_merge.ts (13620 bytes) + numbering_merge.test.ts (10292 bytes): 29 of 29 tests pass on Node 22 AND Node 18; typecheck clean (strict, noUncheckedIndexedAccess, noUnused*); build ok. Coverage: split/ids/picture bullets, id shifts and abstractNumId update, template children kept byte for byte, source list-level pStyle links removed with warning, picture bullet shift, no template numbering, high template ids, numIdMacAtCleanup rule, namespace and mc:Ignorable union, style-link warning, deterministic, unique ids, damaged XML and DOCTYPE; numId remap (mapped, 0 kept, unmapped counted, pPrChange, other elements untouched, chained, other prefix).
- validate.ts (11565 bytes) + validate.test.ts (11933 bytes): 21 of 21 tests pass on Node 22 AND Node 18; typecheck clean; build ok (29.3 kB bundle). Coverage: scanner (ids, styles, lists, bookmarks, sections, pieces of 7 characters, nested sectPr in sectPrChange, damaged XML), every problem code (missing main/root rels/content types, case-only duplicate names, no content type, override without part, missing and outside targets, external targets ignored, duplicate rel ids, unresolved r:id with and without a rels file, header with its own rels, unknown style (warning), unknown list id, no numbering part, duplicate bookmark id/name, bad sectPr), plus ONE real .docx produced by the docx library: zero errors.
- Together in the sandbox: 50 tests in 2 files pass on Node 22 and Node 18. All four files have no "any", no non-null "!", no non-ASCII characters (searched). Drive copies have the same byte sizes as the sandbox copies.
- Earlier chats (NOT redone, still valid): zipio v2 28, package_merge 36, restyle 21, xml_rewrite 32, styles 22 (chat 10); xml 12, template_extract 27, paragraphs/structure 56 (chats 7 to 9). The full Drive suite was NOT rerun together in chat 11.

## CAVEATS (open)
1. restyle.test.ts still needs a run against the real Drive paragraphs.ts and xml.ts (do it when apply.ts is built).
2. numbering_merge was tested on hand-made numbering XML, not on the numbering.xml of a real Word file. validate.ts was tested on one docx-library file only, not on a Word-saved file.
3. Source list definitions using w:styleLink / w:numStyleLink only produce a warning.
4. When the template has no numbering part but the source has one, apply.ts must add the part, relationship and Override (see HANDOFF_v23).
5. validate.ts does not check that every XML part is well formed beyond what the scanner throws, does not check relationship TYPES against content types, and does not check field codes.

## NOT TESTED
1. Real browser (zip.js Web Workers, sax in a browser bundle, file picker, showSaveFilePicker, dev server page): headless browser download blocked.
2. A true 1 GB docx (600 MB tested in chat 6); addBlob parts over 20 MB; zip.js passThrough.
3. Files saved by real Word, LibreOffice, Google Docs.
4. Cancel mid-write on a real disk stream; UTF-16 XML parts; 200 MB document.xml.
5. Lists set only by a style, localized style names, font-based code detection.
6. apply.ts (not built yet); page setup, header/footer inheritance, watermark, sections, captions, cross-references, TOC, tables, images, notes, report, UI, template store, image reduction, batch (not built).
