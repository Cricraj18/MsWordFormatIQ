# formatIQ TEST STATUS v9 (chat 10, sandbox: Linux, 4 GB RAM, 1 CPU; replaces TEST_STATUS_v8)

Method: comment-free full types.ts, package.json, tsconfig.json, vite.config.ts in /home/claude/formatiq. Real zipio.ts v2, comment-free xml.ts, PARTIAL paragraphs.ts (createParagraphHandlers only, copied from Drive). Node 22.22.2 and Node 18.20.8. zip.js 2.23.0, Vitest 2.1.9, TypeScript 5.9.x, Vite 5.4.x, sax 1.x.
NOT redone this chat (tested in chats 7 to 9): 12 xml tests, 27 template_extract tests, 56 paragraphs/structure tests. New or changed tests of chat 10 are listed below.

## TESTED (really run, chat 10)
- npm run typecheck: clean (strict, noUncheckedIndexedAccess, noUnused*) with xml_rewrite.ts, styles.ts, restyle.ts, zipio.ts v2, package_merge.ts and all their tests. No "any" and no non-null "!" in the new code (searched). No non-ASCII characters in the new files (searched; tests use \u escapes where needed).
- npm test on Node 22.22.2: 139 of 139 pass in 5 files (zipio 28, package_merge 36, restyle 21, xml_rewrite 32, styles 22).
- npm test on Node 18.20.8: the same 139 pass.
- npm run build: ok with a temporary entry for package_merge (bundle 23 kB, 9 kB gzip, includes xml_rewrite and sax). Entry restored afterwards.
- package_merge (36 tests): relationship files (parse with decoded entities, write with escaping and round trip, missing attributes skipped, empty list, damaged XML throws); template-owned types (all eight owned, eight non-owned); mergeRelationships (non-owned source kept with own ids, owned source dropped and listed, owned template taken with new ids and a map, template images not taken, ids unique, clash with a tpl id avoided, empty inputs); part names and targets (partDir, relsPathOf, resolveTarget with relative, parent, absolute and dot segments and the undefined result when climbing out, relativeTarget, resolve and relative are inverse); collectPartClosure (follows part rels, ignores external, shared part once, cycle safe, ignores targets leaving the zip); planPartNames and retargetRels (no clash kept, src_ and numbered renames, case-insensitive, same name in different cases, retarget follows renames and keeps external, retarget relative to the new folder); content types (parse, round trip, Override beats Default, Default added for new extension, Override for own type, renamed part uses output name, template entries unchanged and inputs not mutated, parts without a type skipped, pruneOverrides).
- One test expectation was wrong and was corrected, rerun and saved (the code was right).
- zipio v2 (28), restyle (21), xml_rewrite (32), styles (22): as in TEST_STATUS_v8.

## CAVEAT (still open)
restyle.test.ts imports ./xml and ./paragraphs. In the sandbox paragraphs.ts was a PARTIAL copy and xml.ts a comment-free copy. Run restyle.test.ts against the real Drive paragraphs.ts and xml.ts when they are rebuilt.

## NOT TESTED
1. Real browser: zip.js Web Workers, sax in a browser bundle, file picker, showSaveFilePicker, dev server page (headless browser download blocked, see TEST_STATUS_v3).
2. A true 1 GB docx (try about 900 MB if RAM allows; chat 6 did 600 MB: 5.9 s, peak RSS 1.4 GB). addBlob with parts over 20 MB is also untested.
3. zip.js passThrough option (raw copy).
4. Files saved by real Word, LibreOffice, Google Docs (everything so far uses hand-made XML or one library-made file). package_merge was only tried on hand-made relationship and content-type text, not on the .rels of a real Word file.
5. Half-written output after cancel on a real disk stream (needs browser).
6. A 200 MB document.xml through detection, xml_rewrite or restyle (about 12 MB and 100000 paragraphs tested).
7. UTF-16 encoded XML parts (we always decode UTF-8).
8. Lists set only by a style, numbering.xml, localized Word style names, font-based code detection.
9. numbering merge, apply.ts, validate.ts (not built yet; design in HANDOFF_v19 and v20).
10. Page setup, header/footer inheritance, watermark, sections, captions, cross-references, TOC, tables, images, notes, report, UI, template store, image reduction, batch (HANDOFF_v16 and v17 items, not built).
