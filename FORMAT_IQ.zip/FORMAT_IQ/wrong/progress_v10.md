# formatIQ progress v10 (chat 10)

| File | Written | Tests (sandbox) | ChatGPT review | Checked in real Word | Issues |
|---|---|---|---|---|---|
| 0a setup | yes | typecheck + build ok (Node 22) | not needed | n/a | package.json has sax, @types/sax, docx |
| 0b types.ts | yes | typecheck clean | no | n/a | none |
| 0c/0d zipio.ts + test | yes | 22 tests pass (chat 7, Node 22 + 18) | review v1 applied | n/a | not browser-tested |
| 1a-1 xml.ts + xml.test.ts | yes | 12 tests pass (Node 22 + 18) | no | n/a | strips prefixes, cannot write XML back |
| 1a-2 template_extract.ts + test | yes | 27 tests pass (Node 22 + 18) | no | n/a | only library-made .docx tried |
| 2a-1 paragraphs.ts | yes | 18 tests pass (Node 22 + 18) | no | n/a | list set only by a style not seen; numbering.xml not read |
| 2a-2 structure_rules.ts | yes | 24 tests pass (Node 22 + 18) | no | n/a | rules tuned only on made-up and library files |
| 2a-3 structure_detect.ts | yes | 14 tests pass (Node 22 + 18) | no | n/a | two passes over document.xml |
| 3a-1 xml_rewrite.ts + test (NEW) | yes | 32 tests pass (Node 22 + 18) | no | n/a | not tried on a real Word file; works on strings, zip glue comes in 3b |
| 3a-2 styles.ts | NEXT | | | | map roles to template style ids |
| 3b apply.ts | NEXT | | | | paragraph index must match readParagraphs |
| 3c partial apply | NEXT | | | | |

Totals new this chat: 32 tests (xml_rewrite). All run by Claude in the sandbox. The user was not asked to run anything. Clean-up check at the start of chat 10: nothing needed moving (root, src, src/core all clean; sizes matched the handoff).
