# formatIQ TEST STATUS v12 (chat 13; replaces TEST_STATUS_v11; read with HANDOFF_v21, v22, v23, v24)

Method: sandbox (Linux, 4 GB RAM, 1 CPU). Node 22.22.2 and Node 18.20.8 (npm i node@18 in /tmp/n18). Vitest 2.1.9, TypeScript 5.9.3, Vite 5.4.21, sax, @zip.js/zip.js 2.23.0. Sandbox project rebuilt from HANDOFF_v21 facts; sandbox copies of the 14 dependency files (types, xml, zipio, xml_rewrite, restyle, package_merge, numbering_merge, paragraphs, structure_rules, structure_detect, styles, template_extract) are comment-free rewrites made with read_file_content; all typecheck clean (74880 bytes together). validate.ts was NOT in the sandbox this chat.

## TESTED (really run, chat 13)
- src/core/apply.ts (21510 bytes) + apply_sections.ts (10658 bytes) with apply.test.ts (21 tests) and apply_sections.test.ts (11 tests): 32 of 32 pass on Node 22.22.2 AND Node 18.20.8; typecheck clean (strict, noUncheckedIndexedAccess, noUnused*); npm run build ok with a temporary entry (bundle 108 kB, 49 kB gzip; entry and index.html removed afterwards); no "any", no non-null "!", ASCII only (searched). Drive copies have the same byte sizes as the sandbox copies. The real output package was also dumped and read by eye (entries, document.xml, rels, content types, numbering, report): correct.
- Coverage apply.test.ts: package structural checks (every rels target exists, every r:id/r:embed resolves, every part has a content type, no override for a missing part); styles from detected roles (Heading1, Normal, ListParagraph) and direct formatting cleared (jc, spacing, rFonts, sz) or kept with directFormatting "keep"; paragraph text unchanged and same roles after detecting again; styles.xml, header, footer and settings from the template; template body image not copied; source header/footer references replaced in body sectPr and paragraph sectPr (ids tplrId10/tplrId11, titlePg from template); source landscape pgSz kept; source image clashing with a template image renamed (src_logo.png) and rel retargeted; hyperlink External kept; footnotes part and its own image (fn.png) followed; numbering merged (2 nums) and numId remapped in document and footnotes; numbering part added when the template has none (rel, override, numId unchanged); updateFields only with fields, in schema order; manual tag from a given detection (Title); output identical twice, source blob unchanged; missingStyles; report warning "not carried over"; errors INVALID_OPTIONS (scope selected), NOT_DOCX, TEMPLATE_INVALID, ZIP_READ_FAILED (damaged XML), CANCELLED (aborted signal).
- Coverage apply_sections.test.ts: model reader (first sectPr with references, empty model, titlePg val 0, sectPrChange ignored); fixer (replace references, titlePg schema order, xmlns:r added, source titlePg dropped, unmapped template id skipped, references inside sectPrChange removed without new ones, titlePg at end); addUpdateFields (before compat, at end, existing on, existing off turned on).
- One test mistake was fixed on the way (a self-closing element matches a name once, expected 1 not 2); no code bug found.
- Earlier chats (NOT redone, still valid): validate 25 tests (chat 12, Node 22 and 18); numbering_merge 29 (chat 11); zipio v2 28, package_merge 36, restyle 21, xml_rewrite 32, styles 22 (139 tests in chat 10); xml 12, template_extract 27, paragraphs/structure 56 (chats 7 to 9). The full Drive suite was NOT run together in chats 11, 12 or 13 (only the 2 new test files plus implicit use of the 12 dependency files).

## CAVEATS (open)
1. restyle.test.ts and the other old tests still need one run against the real Drive files together (the sandbox has comment-free copies and no old test files). Do it when the whole suite is rebuilt in one sandbox.
2. numbering_merge and apply were tested on hand-made numbering XML and hand-made zips, not on real Word files.
3. apply does not call validate.ts; no test yet runs validateDocx on an apply output (small next task).
4. Scope "selected" (3c) is not built: apply throws INVALID_OPTIONS.
5. All source sections get the same template header/footer references (per-section choices: 5a).
6. Output document.xml is gathered into Blobs in memory; a huge document.xml (hundreds of MB) was not tested with apply.
7. Source docProps title is not copied; template docProps are used.

## NOT TESTED
1. Real browser (zip.js Web Workers, sax in a browser bundle, file picker, showSaveFilePicker, dev server page): headless browser download blocked.
2. A true 1 GB docx (600 MB tested in chat 6 for copy only); addBlob parts over 20 MB; zip.js passThrough.
3. Files saved by real Word, LibreOffice, Google Docs; rendering of the result in Word.
4. Cancel mid-write on a real disk stream; UTF-16 XML parts.
5. Lists set only by a style, localized style names, font-based code detection.
6. Page setup, partial apply, watermark, captions, cross-references, TOC, tables, images, notes handling, report, UI, template store, image reduction, batch (not built).
